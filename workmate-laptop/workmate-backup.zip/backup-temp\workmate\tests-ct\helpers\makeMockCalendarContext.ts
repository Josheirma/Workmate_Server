// tests-ct/helpers/makeMockCalendarContext.ts
import type { CalendarContextType } from "../../src/Scheduling/CalendarContext.js";

export function makeMockCalendarContext(
  overrides: Partial<CalendarContextType> = {}
): CalendarContextType {
  const noop = () => {};

  const base: CalendarContextType = {
   
    users: [],
    setUsers: noop as CalendarContextType["setUsers"],

    selectedDate: null,
    setSelectedDate: noop as CalendarContextType["setSelectedDate"],

    startDate: null,
    setStartDate: noop as CalendarContextType["setStartDate"],

    endDate: null,
    setEndDate: noop as CalendarContextType["setEndDate"],

    user: null,
    setUser: noop as CalendarContextType["setUser"],

    authChecked: true,
    setAuthChecked: noop as CalendarContextType["setAuthChecked"],

    // ⭐ REQUIRED FIELDS THAT WERE MISSING
    firstDayOfYear: null,
    setFirstDayOfYear: noop as CalendarContextType["setFirstDayOfYear"],

    lastDayOfYear: null,
    setLastDayOfYear: noop as CalendarContextType["setLastDayOfYear"],
  };

  return {
    ...base,
    ...overrides,
  };
}
