import React, { useState } from "react";
import { RulesContext, RulesContextType, RulesUser } from "./MakeRulesContext"; // or wherever the context is

interface Props {
  children: React.ReactNode;
}

export default function RulesProvider({ children }: Props) {
  const [rules, setRules] = useState<RulesUser[]>([]);

  const value: RulesContextType = {
  rules,
  setRules
  }
    return <RulesContext.Provider value={ value }>
      {children}
    </RulesContext.Provider>
  
}