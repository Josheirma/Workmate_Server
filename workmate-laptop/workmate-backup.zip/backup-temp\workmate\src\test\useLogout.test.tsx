//Unit test - behavioral - npx vitest run src/test/useLogout.test.tsx

import { describe, it, expect, vi, afterEach } from "vitest";
import { MemoryRouter } from "react-router-dom";
import { renderHook, act, cleanup } from "@testing-library/react";
import { useLogout } from "../Scheduling/Header/hooks/useLogout";

// Mock navigate
const mockNavigate = vi.fn();

vi.mock("react-router-dom", async (importOriginal) => {
  const actual = (await importOriginal()) as any;
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

// Mock Firebase
vi.mock("firebase/auth", () => ({
  getAuth: vi.fn(() => ({})),
  signOut: vi.fn(() => Promise.resolve()),
}));

import { signOut } from "firebase/auth";

const wrapper = ({ children }: any) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(() => {
  vi.clearAllMocks();
  cleanup();
});

describe("useLogout", () => {
  const setUser = vi.fn();
  const setUsers = vi.fn();

  const baseArgs = {
    setUser,
    setUsers,
    authChecked: true,
  };

  it("logs out successfully", async () => {
    const { result } = renderHook(() => useLogout(baseArgs), { wrapper });

    await act(async () => {
      await result.current.logout("LOCAL");
    });

    expect(mockNavigate).toHaveBeenCalledWith("/", { replace: true });
    expect(setUser).toHaveBeenCalledWith(null);
  });

  it("blocks additional logout attempts while busy", async () => {
    const { result } = renderHook(() => useLogout(baseArgs), { wrapper });

    await act(async () => {
      result.current.logout("LOCAL");
      result.current.logout("LOCAL");
    });

    expect(mockNavigate).toHaveBeenCalledTimes(1);
  });

  it("does not logout before authChecked is true", async () => {
    const { result } = renderHook(
      () => useLogout({ ...baseArgs, authChecked: false }),
      { wrapper }
    );

    await act(async () => {
      await result.current.logout("LOCAL");
    });

    expect(signOut).not.toHaveBeenCalled();
  });
});
