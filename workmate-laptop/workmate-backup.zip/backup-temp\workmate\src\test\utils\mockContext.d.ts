import type { CalendarContextType } from "../../Scheduling/CalendarContext";
/**
 * Pure factory to create a fully-typed mock CalendarContext.
 * Immutable, override-safe, and enterprise-grade.
 */
export declare function createMockContext(overrides?: Partial<CalendarContextType>): CalendarContextType;
