import React, { useContext, useEffect, useState, useRef } from "react";
import { CalendarContext } from "./CalendarContext";
import { RulesContext } from "./MakeRulesContext";
import DayComponent from "./DayComponent";
import styles from "./MonthComponent.module.css";
import Header from "./Header/HeaderComponent";
import { useToast } from "./useToast";
import ToastContainer from "./ToastContainer";



const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const monthNames = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December"
];

export default function MonthComponent() {
  const calendarRef = useRef<HTMLDivElement>(null);
  const zoomWrapperRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);

  const [zoom, setZoom] = useState(1); // 1 = 100%
  const [headerHeight, setHeaderHeight] = useState(0);
  const { toasts, showToast } = useToast();

  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);
  const [calendarOverflow, setCalendarOverflow] = useState(0);
  //const [titlebarHeight, setTitlebarHeight] = useState(0);


  if (!ctx || !rulesCtx) {
    throw new Error("MonthComponent must be used within CalendarContext.Provider");
  }

  const { selectedDate, setSelectedDate, firstDayOfYear, lastDayOfYear } = ctx;

  const today = new Date();
  const currentDay = today.getDate();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();

  const [month, setMonth] = useState(currentMonth);
  const [year, setYear] = useState(currentYear);

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startDay = (firstDay.getDay() + 6) % 7; // Monday = 0

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };

  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  const days: (number | null)[] = [
    ...Array(startDay).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1)
  ];

  const isSelectedDate = (day: number | null) => {
    if (!day || !selectedDate) return false;
    const [y, m, d] = selectedDate.split("-").map(Number);
    return y === year && m - 1 === month && d === day;
  };

  const isWithinRange = (dateStr: string) => {
    const d = new Date(dateStr);
    const first = new Date(firstDayOfYear);
    const last = new Date(lastDayOfYear);
    return d >= first && d <= last;
  };


  
useEffect(() => {
  if (headerRef.current) {
    const height = headerRef.current.getBoundingClientRect().height;
    setHeaderHeight(height);
  }
}, []);


//   // Keyboard zoom: Q = +5%, W = -5%  
//   useEffect(() => {
//     //const dpi = window.devicePixelRatio ?? 1;
//     const handleKeyDown = (e: KeyboardEvent) => {
//       if (e.key === "q") setZoom(z => (z + 0.05) );
//       if (e.key === "w") setZoom(z =>  (Math.max(1, z - 0.05))); // no negative zoom
//     };
//     window.addEventListener("keydown", handleKeyDown);
//     return () => window.removeEventListener("keydown", handleKeyDown);
//   }, []);



// Apply zoom and toast
// Inside MonthComponent
// useEffect(() => {
//   console.log("ZOOM EFFECT FIRED", zoom);
//   const wrapper = zoomWrapperRef.current;
//   if (!wrapper) return;
//   let dpi = window.devicePixelRatio; // OS scaling
//   //dpi = .88;
//   //dpi = 1;
//   const correctedZoom = 1 / dpi;    // counteract scaling  - DOES THIS FIX WITH DPR IN MIND?
//   wrapper.style.display = "flex";
//   wrapper.style.justifyContent = "center";
//   wrapper.style.alignItems = "center";
//   wrapper.style.transform = `scale(correctedZoom)`;
//   wrapper.style.transformOrigin = "top center";
//   //wrapper.style.transform = "zoom";
//   //wrapper.style.zoom = String(zoom);

//   //reporting
//   requestAnimationFrame(() => {
//   const rect = wrapper.getBoundingClientRect(); // visual size
//   const logicalWidth = rect.width 
//   const physicalWidth = logicalWidth * (dpi);
//   //const physicalRes = screen.width;//document.documentElement.clientWidth;
//   const drawableResLog = document.documentElement.clientWidth;
//   const physicalRes = drawableResLog * (dpi);
  
//   showToast(
//     `Zoom ${Math.round(zoom*100)}% | logical width ${logicalWidth}px | physical width ${physicalWidth}px | logical drawable viewport ${drawableResLog}px | Physical drawable ${physicalRes}px | DPI ${dpi}`
//   );
// });
// }, []);


// const rootFontSize = parseFloat(
//   getComputedStyle(document.documentElement).fontSize
// );


// console.log("rfs: ", rootFontSize)

//   // const HEADER_FONTSIZEREM = 1.1;
//   // const HEADER_PADDINGTOPEM = 0.1;
//   // const HEADER_PADDINGBOTTOMEM = 0.2;
  


// document.body.style.minWidth = "1500px";

  return ( 
    <div className = {styles.app} >
     
    <div  ref = {headerRef} className={styles.headerFixed}>
      <Header/>
      {/* <Header header_fontsize={HEADER_FONTSIZEREM } header_toppadding={HEADER_PADDINGTOPEM} header_bottompadding={HEADER_PADDINGBOTTOMEM}/> */}
  </div>

<div
  className={styles.pageWrapper}
  style={{paddingTop: `calc(${headerHeight}px`  }}
>
  <div 
    
    className={styles.zoomWrapper}
    style={{  }}
    
  >
    <div className={styles.h2Container}>Select Current Date</div>

    
      <div ref={calendarRef} className={styles.calendar}>
       
        <div className={styles.monthHeader}>
          <div className={styles.leClick}>
            <button onClick={prevMonth}>◀</button>
          </div>
          <div className={styles.monthLabel}>
            {monthNames[month]} {year}
          </div>
          <div className={styles.riClick}>
            <button onClick={nextMonth}>▶</button>
          </div>
        </div>

        {/* Weekdays */}
        <div className={styles.weekdays}>
          {weekdays.map(d => (
            <div key={d} className={styles.weekday}>{d}</div>
          ))}
        </div>

        {/* Grid */}
        <div className={styles.grid}>
          {days.map((day, i) => {
            const isToday =
              day === currentDay &&
              month === currentMonth &&
              year === currentYear;

            return (
              <DayComponent
                key={i}
                day={day}
                isToday={isToday}
                isSelected={isSelectedDate(day)}
                onClick={() => {
                  if (!day) return;
                  const clickedDate =
                    `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
                  if (!isWithinRange(clickedDate)) return;
                  setSelectedDate(clickedDate);
                }}
                className={styles.day}
              />
            );
          })}
        </div>
      </div>
    

    <ToastContainer toasts={toasts} />
    
    {<div className={styles.spacerBottom}></div>}
  </div>

  
</div>

   </div>
  );
}
