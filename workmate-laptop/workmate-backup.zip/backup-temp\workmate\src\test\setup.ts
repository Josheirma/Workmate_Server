/* ============================================================
   BroadcastChannel (spec-compliant multi-instance mock)
=============================================================== */
import { vi } from "vitest";

// Mock all CSS modules
vi.mock("*.module.css", () => ({}));
vi.mock("*.css", () => ({}));


class MockBroadcastChannel {
  static registry = new Map<string, MockBroadcastChannel[]>();

  name: string;
  listeners: Array<(ev: MessageEvent) => void> = [];
  onmessage: ((ev: MessageEvent) => void) | null = null;

  constructor(name: string) {
    this.name = name;

    if (!MockBroadcastChannel.registry.has(name)) {
      MockBroadcastChannel.registry.set(name, []);
    }
    MockBroadcastChannel.registry.get(name)!.push(this);
  }

  addEventListener(type: string, handler: (ev: MessageEvent) => void) {
    if (type === "message") {
      this.listeners.push(handler);
    }
  }

  removeEventListener(type: string, handler: (ev: MessageEvent) => void) {
    if (type === "message") {
      this.listeners = this.listeners.filter((h) => h !== handler);
    }
  }

  postMessage(data: any) {
    const event = new MessageEvent("message", { data });
    const channels = MockBroadcastChannel.registry.get(this.name) || [];

    // Broadcast to ALL channels with this name
    for (const bc of channels) {
      // addEventListener handlers
      for (const listener of bc.listeners) {
        listener(event);
      }
      // onmessage fallback
      bc.onmessage?.(event);
    }
  }

  close() {}
}

Object.defineProperty(globalThis, "BroadcastChannel", {
  configurable: true,
  writable: true,
  value: MockBroadcastChannel,
});


import "@testing-library/jest-dom/vitest";

/* ============================================================
   matchMedia (safe, spec-correct, node-safe)
=============================================================== */
console.log("matchMedia at setup:", window.matchMedia);
console.log("🔥 setup file LOADED");

if (typeof window !== "undefined" && typeof window.matchMedia !== "function") {
  console.log("Polyfilling matchMedia 🔧");

  Object.defineProperty(window, "matchMedia", {
    configurable: true,
    writable: true,
    value(query: string): MediaQueryList {
      return {
        matches: false,
        media: query,
        onchange: null,
        addEventListener: () => {},
        removeEventListener: () => {},
        addListener: () => {},
        removeListener: () => {},
        dispatchEvent: () => true,
      };
    },
  });
}

/* ============================================================
   ResizeObserver (enterprise safe)
=============================================================== */

if (!("ResizeObserver" in globalThis)) {
  class MockResizeObserver implements ResizeObserver {
    private elements: Element[] = [];

    observe(element: Element): void {
      this.elements.push(element);
    }

    unobserve(element: Element): void {
      this.elements = this.elements.filter((el) => el !== element);
    }

    disconnect(): void {
      this.elements = [];
    }
  }

  Object.defineProperty(globalThis, "ResizeObserver", {
    configurable: true,
    writable: true,
    value: MockResizeObserver,
  });
}

/* ============================================================
   IntersectionObserver (full enterprise support)
=============================================================== */

if (!("IntersectionObserver" in globalThis)) {
  class MockIntersectionObserver implements IntersectionObserver {
    readonly root = null;
    readonly rootMargin = "";
    readonly thresholds = [0];

    private readonly callback: IntersectionObserverCallback;

    constructor(callback: IntersectionObserverCallback) {
      this.callback = callback;
    }

    observe(): void {}
    unobserve(): void {}
    disconnect(): void {}

    /** Test-only helper to manually trigger the observer callback. */
    trigger(entries: IntersectionObserverEntry[]): void {
      this.callback(entries, this);
    }

    takeRecords(): IntersectionObserverEntry[] {
      return [];
    }
  }

  Object.defineProperty(globalThis, "IntersectionObserver", {
    configurable: true,
    writable: true,
    value: MockIntersectionObserver,
  });
}

/* ============================================================
   BroadcastChannel (spec-compliant mock)
=============================================================== */

if (!("BroadcastChannel" in globalThis)) {
  class MockBroadcastChannel extends EventTarget implements BroadcastChannel {
    readonly name: string;

    onmessage: BroadcastChannel["onmessage"] = null;
    onmessageerror: BroadcastChannel["onmessageerror"] = null;

    constructor(name: string) {
      super();
      this.name = name;
    }

    postMessage(message: unknown): void {
      const event = new MessageEvent("message", { data: message });

      // EventTarget listeners
      this.dispatchEvent(event);

      // onmessage callback
      if (this.onmessage) {
        this.onmessage.call(this, event);
      }

      // onmessageerror is exposed but not fired automatically.
      // In real browsers, it's only used on structured clone failures.
    }

    close(): void {}
  }

  Object.defineProperty(globalThis, "BroadcastChannel", {
    configurable: true,
    writable: true,
    value: MockBroadcastChannel,
  });
}
