// tests-ct/mocks.ts
console.log("🔥 MOCK MODULE LOADED");

/* =====================================================
   MOCK: useLogout
===================================================== */
export function useLogout() {
  return {
    logout: (origin: string) => {
      window.__logoutCalls ??= [];
      window.__logoutCalls.push(origin);
    },
  };
}


/* =====================================================
   MOCK: useMobileBreakpoint
===================================================== */
export function useMobileBreakpoint() {
  return false; // Always desktop for component tests
}

/* =====================================================
   MOCK: setupLogoutBroadcast
===================================================== */
export function setupLogoutBroadcast() {
  console.log("🔥 Mock setupLogoutBroadcast called");
  return () => {}; // No-op cleanup
}
