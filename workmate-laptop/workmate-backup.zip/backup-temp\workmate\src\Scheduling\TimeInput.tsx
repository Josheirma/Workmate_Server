import React from "react";
import styles from "./TimeInput.module.css";

interface TimeInputProps {
  value: string; // fully controlled
  label?: string;
  onChange: (value: string) => void;
}

export function TimeInput({ value, label, onChange }: TimeInputProps) {

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    //945AM
    const raw = e.target.value.toUpperCase().replace(/[^0-9APM]/g, "");
    let newValue = "";
    let cursorPos = 0;

    for (let i = 0; i < raw.length && newValue.length < 8; i++) {
      const char = raw[i];
      if (!char) continue;

      switch (newValue.length) {
        case 0: // first hour digit
          if (/[0-1]/.test(char)) { newValue += char; cursorPos++; }
          break;

        case 1: { // second hour digit - 01:45 AM.  09:55 PM
          if (!/[0-9]/.test(char)) break;
          const hour = parseInt(newValue[0] + char, 10);
          if (hour >= 1 && hour <= 12) {
            newValue += char;
            cursorPos++;
            newValue += ":"; // auto colon
            cursorPos++;
          }
          break;
        }

        case 3: // first minute digit
        if (/[0-5]/.test(char)) { 
          newValue += char; 
          cursorPos++; 
        }
        break;

      case 4: // second minute digit
        if (/[0|3|5]/.test(char) && 
            parseInt(newValue.slice(3, 4) + char, 10) % 15 === 0) {
          newValue += char;
          cursorPos++;
          newValue += " "; // auto space before AM/PM
          cursorPos++;
        }
        break;

        case 6: // A or P
          if (char === "A" || char === "P") {
            newValue += char;
            cursorPos++;
            newValue += "M"; // auto M
            cursorPos++;
          }
          break;
      }
    }

    onChange(newValue);

    // Restore cursor
    requestAnimationFrame(() => {
      const pos = Math.min(cursorPos, newValue.length);
      e.target.setSelectionRange(pos, pos);
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
  const input = e.currentTarget;
  const pos = input.selectionStart ?? 0;

  if (e.key === "Backspace") {
    e.preventDefault();
    if (pos > 0) {
      // Remove character before cursor but preserve colon/space/AMPM
      const before = value.slice(0, pos - 1);
      const after = value.slice(pos);
      onChange(before + after);
      requestAnimationFrame(() => input.setSelectionRange(pos - 1, pos - 1));
    }
  } else if (e.key === "Delete") {
    e.preventDefault();
    if (pos < value.length) {
      // Remove character at cursor
      const before = value.slice(0, pos);
      const after = value.slice(pos + 1);
      onChange(before + after);
      requestAnimationFrame(() => input.setSelectionRange(pos, pos));
    }
  }
};

  return (
    <div className={styles.inputWrapper}>
      <input
        type="text"
        placeholder={`hh:mm AM/PM${label ? "  " + label.toLowerCase() : ""}`}
        value={value}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        maxLength={8}
        className={styles.input}
      />
      
    </div>
  );
}
