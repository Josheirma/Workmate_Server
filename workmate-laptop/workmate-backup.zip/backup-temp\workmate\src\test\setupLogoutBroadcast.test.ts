//unit test - npx vitest run src/test/setupLogoutBroadcast.test.ts
import { vi } from "vitest";

// Mock logoutChannel to use the global broadcast channel
vi.mock("../Scheduling/Header/logout/logoutChannel", () => ({
  logoutChannel: new BroadcastChannel("app-calendar")
}));

import { describe, it, expect } from "vitest";
import { setupLogoutBroadcast } from "../Scheduling/Header/logout/setupLogoutBroadcast";
import { logoutChannel } from "../Scheduling/Header/logout/logoutChannel";

//console.log("logoutChannel constructor:", logoutChannel?.constructor?.name);

describe("setupLogoutBroadcast", () => {
  it("invokes callback on storage event", () => {
    const callback = vi.fn();
    setupLogoutBroadcast(callback);

    window.dispatchEvent(
      new StorageEvent("storage", { key: "calendarContext:logout" })
    );

    expect(callback).toHaveBeenCalledWith("STORAGE");
  });

  it("invokes callback on broadcast logout", () => {
    const callback = vi.fn();
    setupLogoutBroadcast(callback);

    logoutChannel.postMessage({ type: "logout" });

    expect(callback).toHaveBeenCalledWith("BROADCAST");
  });
});
