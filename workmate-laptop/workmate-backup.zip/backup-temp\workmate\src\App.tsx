
import { BrowserRouter, Routes, Route} from "react-router-dom";
import { CalendarProvider } from "./Scheduling/CalendarProvider";
import Header from "./Scheduling/Header/HeaderComponent";
import DatabaseComponent from "./Scheduling/DatabaseComponent";
import EmployeeListComponent from "./Scheduling/EmployeeListComponent";
import MonthComponent from "./Scheduling/MonthComponent";
import DailyGraphComponent from "./Scheduling/DailyGraphComponent";
import { LayoutComponent } from "./Scheduling/LayoutComponent";
import PrintingComponent from "./Scheduling/PrintingComponent";

import styles from "./App.module.css";
//import "./index.css";
import RulesProvider from "./Scheduling/MakeRulesProvider";
import Rules_MakeRulesComponent from "./Scheduling/Rules_MakeRulesComponent";
import HoursWorkedComponent from "./Scheduling/HoursWorkedComponent"; 
import {Test} from "./Scheduling/Test"
import { useState, useEffect } from "react";
import ActivationScreen from "./Scheduling/ActivationScreen";



const AppContent: React.FC = () => {
  
  const [_headerHeight, set_HeaderHeight] = useState(0);
  const [licensed, setLicensed] = useState<boolean | null>(null)  // null = checking
  // check license on app start
    useEffect(() => {
      window.api.license.verify().then(valid => {
        setLicensed(valid)
      })
    }, [])

    // still checking
    if (licensed === null)
      return <div>Loading...</div>

    // no license → show activation screen
    if (!licensed)
      return <ActivationScreen onActivated={() => setLicensed(true)} />

    // licensed → show full app
    return (
    <>
      

      <Routes>
        
        <Route element={<LayoutComponent />}>


          <Route
            path="/"
             //element={<Test />}
             element={ <DatabaseComponent />}
          />
          
          <Route path="/database" element={<DatabaseComponent />} />
          
          <Route
            path="/schedules"
            element={
              <div className={styles.dailyGraphWrapper}>
                <div className={styles.graphArea}>
                  <DailyGraphComponent setHeight  = {set_HeaderHeight} />
                </div>
                <div className={styles.employeeArea}>
                  <EmployeeListComponent height = {_headerHeight}/>
                </div>
              </div>
            }
          />
          <Route path="/month" element={<MonthComponent />} />
          <Route path="/hrs" element={<HoursWorkedComponent />} />
          <Route path="/print" element={<PrintingComponent />} />
          
          
          
          <Route
            path="/rules"
            element={
          
              <div style={{ paddingBottom: '3rem' }}>
          <Rules_MakeRulesComponent />
            </div>
        
        }
         />
        </Route>
      </Routes>
    </>
  );
};

// 👇 Root App component wraps everything in providers
const App: React.FC = () => {
  return (
    <CalendarProvider>          
      <RulesProvider>
      <BrowserRouter>           
        <AppContent />         
      </BrowserRouter>
      </RulesProvider>
    </CalendarProvider>
  );
};

export default App;
