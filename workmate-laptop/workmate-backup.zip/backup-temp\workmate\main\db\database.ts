// Import the better-sqlite3 library for SQLite database access
import Database from "better-sqlite3";

// Import Node's path module to handle file paths
import path from "path";

// Import Electron's app object to get app-specific paths
import { app } from "electron";

// ✅ Debugging: log when this module is loaded
console.log("database.ts loaded.");

// Construct the full path to the SQLite database file
// app.getPath("userData") points to a per-user, app-specific storage directory
// userData is a keyword
const dbPath = path.join(app.getPath("userData"), "workmate.db");

// ✅ Debugging: log the path to the database file
console.log("DB PATH:", dbPath);

// Open (or create) the SQLite database at dbPath
// This is a synchronous operation; returns a Database instance
const db = new Database(dbPath);

// -------------------------------
// Create the schedules table if it does not already exist
// -------------------------------
// This ensures the database has the proper table structure
// Columns:
//   - id: auto-increment primary key
//   - name: unique text identifier for each schedule
//   - users_json: stores schedule users as a JSON string
//   - rules_json: stores schedule rules as a JSON string
//   - first_day: optional start date for the schedule
//   - last_day: optional end date for the schedule

//NOT NULL - required
db.exec(`
  CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    users_json TEXT,
    rules_json TEXT,
    first_day TEXT,
    last_day TEXT
  );
`);

// -------------------------------
// TEMP DEBUG: Log the actual table schema
// -------------------------------
// PRAGMA table_info(<table>) returns an array describing the table columns
// Useful for verifying that the table exists and has the expected structure
// PRAGMA - query or change db meta data
// schema means the structure or blueprint of the table
console.log(
  "ACTUAL schedules schema:",
  db.prepare("PRAGMA table_info(schedules)").all()
);

// Export the database instance for use in other modules
// This allows other parts of the Electron app to query, insert, or update schedules
export default db;
