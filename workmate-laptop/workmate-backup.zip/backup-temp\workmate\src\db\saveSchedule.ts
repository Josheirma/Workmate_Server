import type { User } from "../Scheduling/CalendarContext";
import type { RulesUser } from "../Scheduling/MakeRulesContext";

interface SaveScheduleArgs {
  scheduleName: string;
  users: User[];
  rules: RulesUser[];
  firstDayOfYear: string;
  lastDayOfYear: string;
}

export async function saveScheduleToDB({
  scheduleName,
  users,
  rules,
  firstDayOfYear,
  lastDayOfYear,
}: SaveScheduleArgs): Promise<void> {
  if (!scheduleName.trim()) {
    throw new Error("Schedule name is required");
  }

  await window.api.schedules.saveSchedule(scheduleName, {
    users,
    rules,
    firstDayOfYear,
    lastDayOfYear,
  });
}
