export const NAV_LINKS = [
    { path: "/database", label: "Files" },
    { path: "/month", label: "Calendar" },
    { path: "/schedules", label: "Schedule" },
    { path: "/rules", label: "Rules" },
    { path: "/hrs", label: "Hrs" },
    { path: "/print", label: "Print" },
    //{ path: "/update", label: "Update" },
];
export const BREAKPOINT = 880;
