// firebase-auth-mock.js

export const onAuthStateChanged = (_auth, callback) => {
  callback(null); // logged out
  if (typeof window !== "undefined") {
    window.__mockAuthState = null; // <-- expose mock value
  }
};

export const signOut = () => {
  return Promise.resolve();
};

// Mock "auth" object to satisfy imports
export const getAuth = () => ({
  currentUser: null
});

// Some builds expect default export
export default {
  onAuthStateChanged,
  signOut,
  getAuth
};
