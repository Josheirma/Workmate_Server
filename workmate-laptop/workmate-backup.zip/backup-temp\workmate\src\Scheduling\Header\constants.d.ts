export declare const NAV_LINKS: {
    path: string;
    label: string;
}[];
export declare const BREAKPOINT = 880;
