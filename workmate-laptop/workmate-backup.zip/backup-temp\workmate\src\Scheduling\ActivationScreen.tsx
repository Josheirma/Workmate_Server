// src/Scheduling/ActivationScreen.tsx
import { useState, useEffect } from "react";

interface Props {
  onActivated: () => void
}

const ActivationScreen: React.FC<Props> = ({ onActivated }) => {
  const [serial, setSerial] = useState("")
  const [error, setError]   = useState("")
  const [loading, setLoading] = useState(false)

  const handleActivate = async () => {
    if (!serial.trim()) return
    setLoading(true)
    setError("")

    const result = await window.api.license.activate(serial.trim())

    if (result.success) {
      onActivated()   // ← tells App.tsx license is valid, load the app
    } else {
      setError(result.error)
    }
    setLoading(false)
  }

  return (
    <div>
      <h1>Activate WorkMate</h1>
      <p>Enter the serial from your box or email.</p>
      <input
        value={serial}
        onChange={e => setSerial(e.target.value)}
        placeholder="WM-XXXX-XXXX-XXXX"
      />
      <button onClick={handleActivate} disabled={loading} style={{ color: "black", background: "white", padding: "8px 16px" }}>
        {/* {loading ? "Activating..." : "Activate"} */}
        Activate
      </button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  )
}

export default ActivationScreen


// When the user enters the serial and clicks Activate:
// ```
// handleActivate()
//     ↓
// window.api.license.activate(serial)   ← calls preload → main.ts → Express server
//     ↓
// success → onActivated() → App.tsx sets licensed=true → full app loads
// failure → show error message