// {
//   // -----------------------------
//   // Compiler behavior
//   // -----------------------------
//   "compilerOptions": {

//     // Target JavaScript version to emit
//     // ES2020 is safe for modern browsers and Electron
//     "target": "ES2020",

//     // Use JavaScript class field semantics (matches modern JS)
//     "useDefineForClassFields": true,

//     // Libraries included in the global scope
//     // DOM = browser APIs
//     // DOM.Iterable = iterable DOM collections
//     // ESNext = modern JS features
//     "lib": ["DOM", "DOM.Iterable", "ESNext"],

//     // Disallow compiling .js files (TypeScript only)
//     "allowJs": false,

//     // Skip type-checking of .d.ts files in node_modules
//     // Speeds up builds, avoids noisy third-party errors
//     "skipLibCheck": true,

//     // Allows default imports from CommonJS modules
//     "esModuleInterop": true,

//     // Allows `import foo from "foo"` even if it has no default export
//     "allowSyntheticDefaultImports": true,

//     // Enable all strict type-checking options
//     "strict": true,

//     // Enforce correct file name casing across OSes
//     "forceConsistentCasingInFileNames": true,

//     // Use ES module syntax (required for Vite)
//     "module": "ESNext",

//     // Node-style module resolution
//     // (NOTE: Bundler is usually better for Vite)
//     "moduleResolution": "Node",

//     // Allow importing JSON files
//     "resolveJsonModule": true,

//     // Required by Vite and other bundlers
//     // Ensures each file can be transpiled independently
//     "isolatedModules": true,

//     // Use the new React JSX transform (React 17+)
//     "jsx": "react-jsx",

//     // -----------------------------
//     // Output settings
//     // -----------------------------

//     // Emit output files (usually false for Vite projects)
//     "noEmit": false,

//     // Output directory for emitted files
//     "outDir": "./dist",

//     // Root directory of *source code*
//     // Everything included must live under src/
//     "rootDir": "src",

//     // -----------------------------
//     // Global types
//     // -----------------------------

//     // Inject test globals like describe(), it(), expect()
//     // ⚠️ These should NOT usually live in app tsconfig
//     "types": ["vitest/globals", "@testing-library/jest-dom"],

//     // Allow implicit `any` types
//     // (weakens type safety; usually discouraged)
//     "noImplicitAny": false
//   },

//   // -----------------------------
//   // Included files
//   // -----------------------------

//   // Files TypeScript considers part of this project
//   // ⚠️ tests-ct and main/db/sqlite.js do NOT live under rootDir "src"
//   "include": ["src/**/*", "tests-ct", "main/db/sqlite.js"],

//   // -----------------------------
//   // Excluded files
//   // -----------------------------

//   "exclude": [
//     // Never include dependencies
//     "node_modules",

//     // Never include build output
//     "dist",

//     // Exclude test files from app build
//     "**/*.test.ts",

//     // Exclude old or unused scripts
//     "scripts/legacy/*"
//   ],

//   // -----------------------------
//   // Project references
//   // -----------------------------

//   // Other TypeScript sub-projects this project depends on
//   "references": [
//     { "path": "./tsconfig.vite.json" },
//     { "path": "./tsconfig.main.json" },
//     { "path": "./tsconfig.test.json" },
//     { "path": "./tsconfig.playwright.json" }
//   ]
// }
