import { useContext, useEffect } from "react";
import {
  DragDropContext,
  Droppable,
  Draggable,
  type DropResult,
} from "@hello-pangea/dnd";
import { RulesContext } from "./MakeRulesContext";
import styles from "./Rules_RulesComponent.module.css";

import { CalendarContext } from "./CalendarContext";
import Header from "../Scheduling/Header/HeaderComponent";



export default function Rules_RulesComponent() {
  const rulesCtx = useContext(RulesContext);
  const ctx = useContext(CalendarContext);
  if (!rulesCtx) {
    throw new Error(
      "RulesComponent must be used within RulesContext.Provider"
    );
  }
  if (!ctx) {
    throw new Error(
      "RulesComponent must be used within RulesContext.Provider"
    );
  }

  const { rules, setRules } = rulesCtx;
  const { users, selectedDate } = ctx;

  
    


        useEffect(() => {
      console.log("calendarCtx", ctx);
      console.log("rulesCtx", rulesCtx);
    }, [ctx, rulesCtx]);


 const handleOrder = () => {
  const usersForSelectedDate = users.filter(u => u.date === selectedDate);
  const userIDs = new Set(usersForSelectedDate.map(u => u.userID));

  setRules(prev => {
    const restricted: typeof prev = [];
    const normal: typeof prev = [];

    prev.forEach(rule => {
      // Conflict only if both users are present for the selected date
      const isRestricted = userIDs.has(rule.userID1) && userIDs.has(rule.userID2);

      if (isRestricted) restricted.push(rule);
      else normal.push(rule);
    });

    // Restricted rules first, then the rest in original order
    return [...restricted, ...normal];
  });
};



  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    setRules(prev => {
      const reordered = [...prev];
      const [moved] = reordered.splice(result.source.index, 1);
      reordered.splice(result.destination.index, 0, moved);
      return reordered;
    });
  };

  return (
    <>
    
      <Header/>
    
    <div className= {styles.pageWrapper}>
      <h1>Rules</h1>
        
        <div className={styles.container}>
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="rulesList" type="rule">
              {(provided) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={styles.list}
                >
                  
                  {rules.map((rule, index) => {
                    const ruleId = `${rule.userID1}-${rule.userID2}`;
                    const usersForSelectedDate = users.filter(u => u.date === selectedDate);
                    // Check if either user in the rule exists in usersForSelectedDate
                    const ruleIsRestricted = (() => {
                      const userIDs = new Set(usersForSelectedDate.map(u => u.userID));
                      return userIDs.has(rule.userID1) && userIDs.has(rule.userID2);
                    })();


                    return (
                      <Draggable
                        key={ruleId}
                        draggableId={ruleId}
                        index={index}
                      >
                        {(prov) => (
                       <div
                          ref={prov.innerRef}
                          {...prov.draggableProps}
                          {...prov.dragHandleProps}
                          className={`${styles.item} ${ruleIsRestricted ? styles.restricted : ''}`}
                          role="button"
                          tabIndex={0}
                        >
                          {ruleIsRestricted && (
                            <span className={styles.icon} aria-label="Restricted" title="Restricted">
                               ❗
                            </span>
                          )}
                          {rule.fullName1} ↔ {rule.fullName2}
                        </div>

                        )}
                      </Draggable>
                    );
                  })}


                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>

          <div className={styles.buttonRow}>
            <button className={styles.button} onClick={handleOrder}>
              Order
            </button>
          </div>
        </div>
      </div>
      </>
    
  );
}