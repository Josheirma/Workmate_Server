import { app, BrowserWindow, ipcMain } from "electron";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import os from "os";
import crypto from "crypto";
import log from "electron-log";
import "./ipc/schedulesIpc.js";

app.setPath("userData", "C:/electron-cache/workmate");
app.setPath("cache", "C:/electron-cache/workmate/cache");
app.disableHardwareAcceleration();

console.log("schedulesIpc imported.");
log.debug("test");

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log("MAIN FILE:", import.meta.url);
console.log("DIR:", __dirname);

// ─── LICENSE ──────────────────────────────────────────────────────

const PUBLIC_KEY = fs.readFileSync(
  path.join(__dirname, "../../public.pem"), "utf8"
)

function getMachineID(): string {
  const data = os.hostname() + os.arch()
  return crypto.createHash("sha256").update(data).digest("hex")
}

function saveLicense(license: object): void {
  fs.writeFileSync(
    path.join(app.getPath("userData"), "license.dat"),
    JSON.stringify(license, null, 2)
  )
}

function verifyLicense(): boolean {
  const licensePath = path.join(app.getPath("userData"), "license.dat")

  if (!fs.existsSync(licensePath))
    return false

  const license = JSON.parse(fs.readFileSync(licensePath, "utf8"))
  const { serial, machineID, signature } = license

  if (machineID !== getMachineID())
    return false

  const payload = JSON.stringify({ serial, machineID })

  return crypto.verify(
    "sha256",
    Buffer.from(payload),
    {
      key: PUBLIC_KEY,
      padding: crypto.constants.RSA_PKCS1_PSS_PADDING
    },
    Buffer.from(signature, "base64")
  )
}

async function activate(serial: string) {
  const machineID = getMachineID()

  const response = await fetch("http://localhost:3000/activate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ serial, machineID })
  })

  const result = await response.json()

  if (result.success) {
    saveLicense(result.license)
  }

  return result
}

// ─── IPC HANDLERS ─────────────────────────────────────────────────

ipcMain.handle("license:verify",   () => verifyLicense())
ipcMain.handle("license:activate", (_e, serial: string) => activate(serial))

// ─── WINDOW ───────────────────────────────────────────────────────

let mainWindow: BrowserWindow | null = null;

async function createWindow() {
  console.log("Creating BrowserWindow…");

  const preloadPath = path.join(__dirname, "preload.js");

  console.log("Preload path exists?", fs.existsSync(preloadPath));

  if (!fs.existsSync(preloadPath)) {
    console.error("❌ PRELOAD FILE NOT FOUND!");
    return;
  }

  if (mainWindow) {
    mainWindow.close();
  }

  mainWindow = new BrowserWindow({
    backgroundColor: "#ffffff",
    width: 1240,
    height: 800,
    minWidth: 540,
    minHeight: 800,
    autoHideMenuBar: true,
    resizable: true,
    useContentSize: true,
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
    },
  });

  mainWindow.setMenuBarVisibility(false);

  mainWindow.webContents.on("preload-error", (_e, path, error) => {
    console.error("❌ PRELOAD ERROR:", path, error);
  });

  try {
    await mainWindow.loadURL("http://localhost:5173");
  } catch (err) {
    console.error("❌ Failed to load Vite:", err);
    return;
  }

  mainWindow.on("resize", () => {
    const bounds = mainWindow!.getBounds();
    console.log("Window resized to:", bounds.width, "x", bounds.height);
  });

  mainWindow.webContents.on("did-finish-load", () => {
    console.log("✅ Renderer loaded");

    const bounds = mainWindow!.getBounds();
    const contentBounds = mainWindow!.getContentBounds();
    const minSize = mainWindow!.getMinimumSize();

    console.log("Window bounds:", bounds);
    console.log("Content bounds:", contentBounds);
    console.log("Minimum size:", minSize);
    console.log("Frame height difference:", bounds.height - contentBounds.height);

    mainWindow!.webContents.executeJavaScript(`
      console.log("=== RENDERER CHECK ===");
      console.log("window.api:", window.api);
    `);

    if (!app.isPackaged) {
      mainWindow!.webContents.openDevTools({ mode: "right" });
    }
  });
}

app.whenReady().then(() => {
  console.log("Electron app ready.");
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});