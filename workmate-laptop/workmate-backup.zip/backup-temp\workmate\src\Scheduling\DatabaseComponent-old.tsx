// import React, { useState, useContext, useEffect} from "react";
// import { db, auth } from "./firebase";
// import { doc, getDoc, setDoc } from "firebase/firestore";
// import { CalendarContext, User } from "./CalendarContext";
// import { RulesContext, RulesUser } from "./MakeRulesContext";
// import styles from "./DatabaseComponent.module.css";
// import { loadFromLocalStorage } from "./utility";
// import { startTransition } from "react";
// import { runTransaction } from "firebase/firestore";


// interface Schedule {
//   users: User[];
//   rules: RulesUser[];
// }

// export default function DatabaseComponent() {
//   const ctx = useContext(CalendarContext);
//   const rulesCtx = useContext(RulesContext);

//   if (!ctx) throw new Error("Database Component must be used within CalendarContext.Provider");
//   if (!rulesCtx) throw new Error("Database Component must be used within RulesContext.Provider");

//   const { setRules, rules } = rulesCtx;
//   const {  users, setUsers, selectedDate } = ctx;

//   const clearContexts = () => {
    
//     setUsers([]);
//     setRules([]);
   
// };

//   const [loadedSchedules, setLoadedSchedules] = useState<string[]>([]);
//   const [scheduleName, setScheduleName] = useState<string>("");
//   const [activeSchedule, setActiveSchedule] = useState<string | null>(null);
//   const [deleteLoading, setDeleteLoading] = useState<string | null>(null);
//   const [saveLoading, setSaveLoading] = useState(false);
//   const [selectLoading, setSelectLoading] = useState<string | null>(null);
//   const [username, setUsername] = useState("");
//   const [isOnMount, setIsOnMount] = useState(true);

//   useEffect(() => {
//     loadFromLocalStorage(ctx, rulesCtx);
//   }, [])


//   // ✅ Auth 
//   useEffect(() => {
//       auth.onAuthStateChanged(user => {
//       const uname = user?.email?.split("@")[0] || "";
//       setUsername(uname);
      
      
//     });
//   }, []);


//   // 🔹 Load saved active schedule from localStorage
//   useEffect(() => {
//     const saved = localStorage.getItem("activeSchedule");
//     if (saved) setActiveSchedule(saved);
//     setIsOnMount(true);
//   }, []);

//   useEffect(() => {
//     if (isOnMount) return;
//     if (activeSchedule) {
//       localStorage.setItem("activeSchedule", activeSchedule);
      
//     }
//   }, [activeSchedule]);


//   useEffect(() => {
//     setIsOnMount(false);
//   }, []);



//   // 🔹 Load all schedules from Firestore
//   useEffect(() => {
//     if (!username) {
//       return;
//     }

//     let cancelled = false;

//     const loadSchedules = async () => {
//       try {
//         //pointer
//         const ref = doc(db, "users", username);
//         //methods and meta data
//         const snap = await getDoc(ref);
//         if (cancelled) return;

//         if (!snap.exists()) {
//           if (cancelled) return;
//           //setLoadedSchedules([]);
//           setActiveSchedule(null);
         
//           return;
//         }

//         //document
//         const data = snap.data() ?? {};
//         //all schedules data
//         const schedules = data.schedules ?? {};
//         //gets key (schedule name)
//         const scheduleList = Object.keys(schedules);

//         if (cancelled) return;
//         setLoadedSchedules(scheduleList);

//         if (!activeSchedule) return;
//         const sched = schedules[activeSchedule];
//         if (cancelled) return;
//         if (!sched) {
          
//           setActiveSchedule(null);
//           clearContexts();
//           return;
//         }

//         const { users = []} = sched;
        
//         if (cancelled) return;
//         startTransition(() => {
//         setUsers(users);
//         setRules(rules);
//         });

//         localStorage.setItem(
//           "calendarContext",
//           JSON.stringify({ users,  rules, selectedDate: selectedDate ?? "" })
//         );
//       } catch{
//         if (cancelled) return;
//         //console.error("Failed to load schedules:", err);
//         alert("❌ Could not load schedules. Try refreshing.");
//       }
//     };

//     loadSchedules();

//     return () => {
//       cancelled = true;
//     };
//   }, [username]);

//   const saveToLocalStorage = (users: User[]) => {
//       const data = {
//       users,
//       selectedDate: selectedDate ?? "",
//     };

//     localStorage.setItem("calendarContext", JSON.stringify(data));
//   };

//   //loads
//   const handleSelectSchedule = async (scheduleName: string) => {
//     if (selectLoading) return;
    
//     if (!loadedSchedules.includes(scheduleName)) {
//       setActiveSchedule(null);
//       alert(`❌ Schedule "${scheduleName}" does not exist.`);
//       return;
//     }
//     if (!username) return;

   

//     const currentSchedule = scheduleName;
//     try {
//       setSelectLoading(scheduleName);

//       //pointer
//       const ref = doc(db, "users", username);
//       //metods and met data
//       const snap = await getDoc(ref);
      
//       if (!snap.exists()) {
//         //clearContexts();
//         setActiveSchedule(null);
//         return;
//       }

//       //complete document
//       const data = snap.data();
      
//       //single schedule
//       const schedule = data?.schedules?.[currentSchedule];
      
//       if (!schedule) {
//         alert("Missing schedule");
        
//         return;
//       }

//       const loadedUsers = schedule.users || [];
//       const loadedRules = schedule.rules || [];

//       startTransition(() => {
//       //prevent stale data
//       clearContexts();
//       ctx.setUsers(loadedUsers);
//       rulesCtx.setRules(loadedRules);
//       //setActiveSchedule(currentSchedule);
      
//       });
//       saveToLocalStorage(loadedUsers);

      
      
//     } catch (err: unknown) {
      
//       alert(err instanceof Error ? `❌ Failed to load schedule: ${err.message}` : "❌ Failed to load schedule: Unknown error");
//     } finally {
//       setSelectLoading(null);
//     }
    
//   };

//   const handleSave = async () => {
//     if (saveLoading) return;
//     if (!scheduleName.trim()) return void alert("❌ Please enter a schedule name.");
//     if (/[.#$/[\]]/.test(scheduleName)) return alert("❌ Schedule name contains invalid characters.");
//     if (!username) return alert("❌ No username found.");
//     if (loadedSchedules.map(n => n.toLowerCase()).includes(scheduleName.toLowerCase())) {
//       alert("❌ Schedule already exists.");
//       return;
// }

//     setSaveLoading(true);

    
//     const ref = doc(db, "users", username);

//     try {
      
//       await runTransaction(db, async (transaction) => {
//         //contains methods and meta data
//         const docSnap = await transaction.get(ref);
        
//         //holds entire document
//         const data = docSnap.exists() ? docSnap.data() : {};

//         const existingSchedules = data.schedules || {};

//         // ---------- Build a "clean" schedules object ----------
//         const newSchedules: Record<string, Schedule> = {};

//         // Keep any schedules still listed in loadedSchedules
//         for (const name of loadedSchedules) {
//           if (existingSchedules[name]) {
//             newSchedules[name] = existingSchedules[name];
//           }
//         }

//         // Always include the one you're saving
//         // create a single entry
//         newSchedules[scheduleName] = {
//           users: users,
//           rules: rules,
//         };

//         // ---------- Write back ----------
//         transaction.set(
//           ref,
//           { schedules: newSchedules }
          
//         );
//       });

//       setLoadedSchedules(prev => (prev.includes(scheduleName) ? prev : [...prev, scheduleName]));
//       setActiveSchedule(scheduleName);
//       alert(`✅ Saved "${scheduleName}" successfully.`);
//     } catch (err: unknown) {
//       alert(err instanceof Error ? `❌ Save failed:\n${err.message}` : "❌ Save failed: Unknown error");
//     } finally {
//       setSaveLoading(false);
//     }
//   };




//   const clearCurrentFile = () => {
//     if (!window.confirm("Are you sure you want to create a new database?")) return;
//       clearContexts()
//       rulesCtx.setRules([]);
//       localStorage.removeItem("calendarContext");
//       localStorage.setItem(
//       "calendarContext",
//       JSON.stringify({
//         users: [],
//         rules: [],
//         selectedDate: "",
//       })
//     );
//     alert(`✅ New database created!`);
//   };




//   const handleDelete = async (name: string) => {
//     if (!username) return alert("❌ No username found.");
//     if (deleteLoading) return;
//      setDeleteLoading(name);
//     const ok = window.confirm(`⚠️ Are you sure you want to delete "${name}"? This cannot be undone.`);
//     if (!ok) {
      
//       return;
//     }

//     try {
     
//       //pointer
//       const ref = doc(db, "users", username);
//       //methods and meta data
//       const snap = await getDoc(ref);
//       if (!snap.exists()) {
//         alert("❌ User database not found.");
        
//         return;
//       }

//       //entire document
//       const data = snap.data();
//       //all schedules
//       const schedules = { ...(data.schedules || {}) };
//       if (!schedules[name]) {
//         alert(`❌ Schedule "${name}" does not exist or already deleted.`);
        
//         return;
//       }
//       //one schedule - removes it
//       delete schedules[name];
//       //save
//       await setDoc(ref, { ...data, schedules });

//       setLoadedSchedules(prev => prev.filter(s => s !== name));
//       if (activeSchedule === name) {
//         setActiveSchedule(null);
//         localStorage.removeItem("activeSchedule");
        
//       }

//       alert(`🗑️ Successfully deleted schedule "${name}".`);
//     } catch (err) {
//       console.error(err);
//       alert("❌ Failed to delete schedule.");
//     } finally {
//       setDeleteLoading(null);
//     }
//   };

//   return (
//     <div className={styles.pageWrapper}>
//       <div className={styles.controlPanel}>
//         <div className={styles.topSection}>
//           <button onClick={clearCurrentFile} className={styles.button}>New Database</button>
//         </div>
//         <input
//           type="text"
//           placeholder="Enter schedule name"
//           aria-label="Schedule name"
//           value={scheduleName}
//           onChange={e => setScheduleName(e.target.value)}
//           onKeyDown={(e) => {
//             if (e.key === "Enter") {
//               e.preventDefault();    // ⬅️ stops form submission / button click / unwanted focus shift
//               if (!saveLoading) {
//                 handleSave();
//               }
//             }
//           }}
//           className={styles.inputBox}
//           disabled={saveLoading}
//         />
//         <div className={styles.saveSection}>
//         <button
//           type="button"
//           className={styles.button}
//           disabled={saveLoading}
//           onClick={(e) => {
//             e.preventDefault();
//             handleSave();
//           }}
//         >
//           Save
//         </button>

//         <div className={styles.savingWrapper}>
//           {saveLoading && <span className={styles.savingMessage}>Saving…</span>}
//         </div>
//       </div>


//       </div>

//    <div className={styles.listContainer}>
//       {loadedSchedules.length === 0 ? (
//         <p className={styles.emptyText}>No schedules found.</p>
//       ) : (
//         <>
//           <ul className={styles.scheduleList}>
//             {loadedSchedules.map(name => (
//               <li
//                 key={name}
//                 className={`${styles.listItem} ${
//                   activeSchedule === name ? styles.active : ""
//                 } ${selectLoading === name ? styles.disabled : ""}`}
//                 onClick={() => handleSelectSchedule(name)}
//               >
//                 <span>{name}</span>
//                 <button
//                   className={styles.deleteButton}
//                   disabled={deleteLoading === name}
//                   onClick={e => {
//                     e.stopPropagation();
//                     handleDelete(name);
//                   }}
//                 >
//                   ×
//                 </button>
//               </li>
//             ))}
//           </ul>

          
          
//         </>
//       )}
//     </div>

//         <div className={styles.loadingWrapper}>
//           {selectLoading && <span className={styles.loading}>Loading…</span>}
//         </div>

//     </div>
//   );
// }
