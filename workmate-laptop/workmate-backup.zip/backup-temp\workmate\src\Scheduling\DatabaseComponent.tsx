import React, {
  useState,
  useContext,
  useEffect,
  useRef,
  startTransition,
  
} from "react";
import { CalendarContext, User } from "./CalendarContext";
import { RulesContext, RulesUser } from "./MakeRulesContext";
import styles from "./DatabaseComponent.module.css";

import { useToast } from "./useToast";
import ToastContainer from "./ToastContainer";
import { saveScheduleToDB } from "../db/saveSchedule";
import ConfirmModal from "./ConfirmModal"
import classNames from "classnames";
import Header from "../Scheduling/Header/HeaderComponent"




export default function DatabaseComponent() {
  console.log("Rendering DatabaseComponent");

  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);
  const { toasts, showToast } = useToast();
  const [confirmOpenSave, setConfirmOpenSave] = useState(false);
  const [confirmOpenDelete, setConfirmOpenDelete] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [draftNameSetup, setDraftNameSetup] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [DBLoadedOrCreated, setDBLoadedOrCreated] = useState(false)
  const [needsSpacing, setNeedsSpacing] = useState(false);
  const [headerHeight, setHeaderHeight] = useState(0);
  const headerRef = useRef<HTMLDivElement | null>(null);

  if (!ctx)
    throw new Error(
      "DatabaseComponent must be used within CalendarContext.Provider"
    );
  if (!rulesCtx)
    throw new Error(
      "DatabaseComponent must be used within RulesContext.Provider"
    );

  const {
    users,
    setUsers,
    setSelectedDate,
    firstDayOfYear,
    setFirstDayOfYear,
    lastDayOfYear,
    setLastDayOfYear,
    setScheduleName,
    scheduleName,
  } = ctx;

  const { rules, setRules } = rulesCtx;

  

  const [loadedSchedules, setLoadedSchedules] = useState<string[]>([]);
  const [activeSchedule, setActiveSchedule] = useState<string | null>(null);
  const [deleteLoading, setDeleteLoading] = useState<string | null>(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const [selectLoading, setSelectLoading] = useState<string | null>(null);
  const [dateEntered, setDateEntered ] = useState(false);
  const [, setScheduleEntered] = useState(false);

  const scheduleInputRef = useRef<HTMLInputElement | null>(null);
  const didInitRef = useRef(false);
  const [needsBottomSpacing, setNeedsBottomSpacing] = useState(false);
  

  const clearContexts = () => {
    setUsers([]);
    setRules([]);
  };

  

  
  
  function getEndDateFromStart(startDateISO: string): string {
    const start = new Date(startDateISO);
    if (isNaN(start.getTime())) return "";

    const end = new Date(start);
    end.setFullYear(start.getFullYear() + 1);

    const day = end.getDay(); // 0 = Sunday
    const daysUntilSunday = (7 - day) % 7;
    end.setDate(end.getDate() + daysUntilSunday);

    return end.toISOString().split("T")[0];
  }


  


useEffect(() => {
  const header = headerRef.current;
  if (!header) return;
  const observer = new ResizeObserver(entries => {
    for (const entry of entries) {
      setHeaderHeight(entry.contentRect.height);
    }
  });
  observer.observe(header);
  return () => observer.disconnect();
}, []);


  // Load active schedule from localStorage
  useEffect(() => {
    
      const isScheduleLoaded = !!scheduleName;
      if(!isScheduleLoaded){
      setDateEntered(false);
      setFirstDayOfYear("");
      setLastDayOfYear("");
      setActiveSchedule("");
      setUsers([]);
      setRules([]);
      }
      
      
  }, []);



  // Load available schedules
  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const names = await window.api.schedules.listSchedules();
        if (!cancelled)  setLoadedSchedules([...names].reverse());
      } catch {
        // showToast("❌ Could not load schedules list.");
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);


  
  

  function handleDeleteClick(name: string) {
  setDeleteTarget(name);   
  setConfirmOpenDelete(true);   
}

  const handleDelete = async (name: string) => {
    if (deleteLoading) return;

    //const ok = await window.api.confirmDelete(name);
    //if (!ok) return;

    try {
      setDeleteLoading(name);

      await window.api.schedules.deleteSchedule(name);

      setLoadedSchedules(prev => prev.filter(s => s !== name));

      if (activeSchedule === name) {
        setActiveSchedule(null);
        setScheduleName("");   
        setDraftName("");     
        setScheduleEntered(false);  
        setDateEntered(false);      

        
      }

      showToast(`🗑️ Successfully deleted schedule "${name}".`);
    } catch {
      showToast("❌ Failed to delete schedule.");
    } finally {
      setDeleteLoading(null);
    }
  };


  
  
  //loads
  const handleSelectSchedule = async (name : string) => {

    
  
  if (selectLoading) return;

  if (!loadedSchedules.includes(name)) {
    showToast(`❌ Schedule "${name}" does not exist.`);
    return;
  }

  try {
    setSelectLoading(name);

    const schedule = await window.api.schedules.getSchedule(name);
    if (!schedule) {
      showToast("❌ Missing schedule!");
      return;
    }

      const loadedUsers = schedule.users?.map(u => ({
      userID: u.id,
      fullName: u.name,
      shifts: [],   // or map from API if available
      date: "",     // or map from API if available
    })) || [];


    const loadedRules: RulesUser[] = (schedule.rules || []).map(rule => ({
  userID1: "", // assign default or map if API has data
  userID2: "",
  fullName1: rule.name, // maybe use rule.name if appropriate
  fullName2: "",
  isRestricted: false, // default
  // add other fields if necessary
}));

    const firstDay = schedule.firstDayOfYear ?? "";
    const lastDay = schedule.lastDayOfYear ?? "";
    const date = schedule.firstDayOfYear ?? "";

    startTransition(() => {
      clearContexts();
      setUsers(loadedUsers);
      setRules(loadedRules);
      setFirstDayOfYear(firstDay);
      setLastDayOfYear(lastDay);
      setSelectedDate(date);
      //setActiveSchedule(name);
      
    });

    

    // ✅ Success toast (after everything loads)
    showToast(`✅ Schedule "${name}" loaded successfully!`);
  } catch (err) {
    showToast(
      err instanceof Error
        ? `❌ Failed to load schedule: ${err.message}`
        : "❌ Failed to load schedule"
    );
  } finally {
    setSelectLoading(null);
    setScheduleEntered(true);
    setDateEntered(true);
    setScheduleName(name);
    setDraftName(name); 
    setDBLoadedOrCreated(true);
    //setDraftNameSetup("")

  }
};


  function  DatabaseSetupPress() {
  //if (saveLoading) return false;


  const name = draftNameSetup.trim();
  
  if (!name) return;

  // 🔔 CHECK: schedule already exists
  if (loadedSchedules.includes(name)) {
    showToast(`⚠️ A schedule named "${name}" already exists.`);
    return;
  }

  if (/[.#$/[\]]/.test(name)) {
    showToast("❌ Schedule name contains invalid characters!");
    return false;
  }


  setDraftName(name)

  const initialDate = firstDayOfYear ?? "";

  

  setSelectedDate(initialDate);
  setScheduleEntered(true);
  setScheduleName(name)
  
  setDBLoadedOrCreated(true);

  //setSaveLoading(true);

  // try {
  //   await saveScheduleToDB({
  //     scheduleName: draftNameSetup,
  //     users,
  //     rules,
  //     firstDayOfYear,
  //     lastDayOfYear,
  //   });

  //   setLoadedSchedules(prev =>
  //     prev.includes(name) ? prev : [name, ...prev]
  //   );

  //   showToast(`✅ Database created!`);
  // } catch (err) {
  //   showToast(
  //     err instanceof Error
  //       ? `❌ Save failed:\n${err.message}`
  //       : "❌ Save failed"
  //   );
  // } finally {
  //   setSaveLoading(false);
  //   setTimeout(() => scheduleInputRef.current?.focus(), 50);
  //   scheduleInputRef.current.value = ""
    
  //   setDraftNameSetup("")
  // }
};


function handleSaveClick() {
  //setDeleteTarget();   
  if(!scheduleName){
    showToast("❌ No Schedule loaded!");
    return
  }
  setConfirmOpenSave(true);   
  }


const handleSavePress = async (

) => {
  if (saveLoading) return ;


  const name = draftName.trim();
  //setDraftName(draftName)
  if (!name) return;

  const initialDate = firstDayOfYear ?? "";

  

  setSelectedDate(initialDate);
  setScheduleEntered(true);
  

  if (/[.#$/[\]]/.test(name)) {
    showToast("❌ Schedule name contains invalid characters!");
    return false;
  }

  setSaveLoading(true);

  try {
    await saveScheduleToDB({
      scheduleName: draftName,
      users,
      rules,
      firstDayOfYear,
      lastDayOfYear,
    });

    setLoadedSchedules(prev =>
      prev.includes(name) ? prev : [name, ...prev]
    );

    showToast(`✅ Saved "${name}" successfully!`);
  } catch (err) {
    showToast(
      err instanceof Error
        ? `❌ Save failed:\n${err.message}`
        : "❌ Save failed"
    );
  } finally {
    setSaveLoading(false);
    setTimeout(() => scheduleInputRef.current?.focus(), 50);
    //scheduleInputRef.current.value = ""
    //setDraftName(name)
    //setDraftNameSetup("")
  }
};



  




  

  return (
    <div>
    <div ref = {headerRef} className={styles.headerFixed}>
    <Header 
      onSaveDatabase={handleSaveClick} 
      isSaveDisabled={!DBLoadedOrCreated} 
        />
    </div>
    
    <div className={styles.pageWrapper}
      //fixed header removed from layout so use padding
      style={{paddingTop: `calc(${headerHeight}px`  }}>
      
      <div className={styles.controlPanel}>
        
        <div className={styles.topSection}>
          {/* Date inputs */}
          
          <strong className={styles.currentSchedule}>
            {scheduleName
              ? `Current schedule: ${scheduleName}`
              : "No schedule loaded"}
          </strong>
          <div className={styles.dateRow}>
            
            <div className={styles.dateField}>
              <label className={styles.dateLabel}>Starting date</label>
              <input
                type="date"
                onChange={e => {
                  const start = e.target.value;
                  setFirstDayOfYear(start);
                  setLastDayOfYear(getEndDateFromStart(start));
                  setDateEntered(true);
                }}
                className={styles.inputBox}
              />
            </div>

            <div className={styles.dateField}>
              <label className={styles.dateLabel}>
                Ending date (the upcoming Sunday)
              </label>
              <input
                type="date"
                value={lastDayOfYear ?? ""}
                disabled
                className={styles.inputBox}
              />
            </div>
          </div>
          <div className={styles.textField}>
          <label className={styles.centerLabel}>
            Enter schedule name.
          </label>

          {/*Input for database save press  */}
          <input
            ref={scheduleInputRef}
            value={draftNameSetup}
            onChange={e => {
              //setDraftName(e.target.value);
              setDraftNameSetup(e.target.value)
              
            }}
            className= {classNames( styles.inputBox, styles.schedInput)}
            disabled={saveLoading}
          />
        </div>
        
          <button
            onClick={DatabaseSetupPress}
            className={styles.button}
            disabled={
              
              !dateEntered ||
              !draftNameSetup
            }
          >
            New Database
        </button>
        
        
        

        

        
      

      <label className={styles.listLabel}>Your schedules, click to load.</label>

      <div className={styles.listContainer}>
        {loadedSchedules.length === 0 ? null : (
          <ul className={styles.scheduleList}>
            {loadedSchedules.map(name => (
              <li
                key={name}
                className={`${styles.listItem} ${
                  activeSchedule === name ? styles.active : ""
                } ${selectLoading === name ? styles.disabled : ""}`}
                onClick={() => handleSelectSchedule(name)}
              >
                <div className={styles.scheduleName}>{name}</div>
                <button
                  className={classNames(styles.button, styles.deleteButton)}
                  disabled={deleteLoading === name}
                  onClick={e => {
                    e.stopPropagation();
                    void handleDeleteClick(name);
                  }}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
        <div className={styles.saveSection}>
          <button
            className={classNames(styles.button, styles.saveButton)}
            
            onClick={handleSaveClick}
            disabled = {!DBLoadedOrCreated}
          >
            Save
          </button>

          {saveLoading && (
            <div>
            <label className={styles.listLabel}>Saving…</label>
            </div>
          )}
        </div>
        
      {selectLoading && (
        <div>
          <label className={styles.listLabel}>Loading…</label>
        </div>
      )}

      {/* <ConfirmModal
        open={confirmOpenDelete}
        title="Delete schedule?"
        message="This action cannot be undone."
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteTarget) {
            void handleDelete(deleteTarget); // 🔥 delete happens HERE
          }
          setConfirmOpenDelete(false);
          setDeleteTarget(null);
        }}
        onCancel={() => {
          setConfirmOpenDelete(false);
          setDeleteTarget(null);
        }}
      />

      <ConfirmModal
        open={confirmOpenSave}
        title="Saving Schedule"
        message="Changes will be saved to the current schedule."
        confirmLabel="Save"
        onConfirm={async () => {
          //if (deleteTarget) {
            await handleSavePress(); // 🔥 delete happens HERE
          //}
          setConfirmOpenSave(false);
          setDeleteTarget(null);
        }}
        onCancel={() => {
          setConfirmOpenSave(false);
          setDeleteTarget(null);
        }}
      />

      <ToastContainer toasts={toasts} /> */}
    </div>
    {<div className={styles.spacerBottom}></div>}
    </div>
    </div>
    
    </div>
  );
}
