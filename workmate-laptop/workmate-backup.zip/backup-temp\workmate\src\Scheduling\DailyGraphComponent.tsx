import React, { useContext, useState, useEffect, useRef } from "react";
import styles from "./DailyGraphComponent.module.css";
import { CalendarContext, Shift, User } from "./CalendarContext";
import { RulesContext } from "./MakeRulesContext";
import Header from "../Scheduling/Header/HeaderComponent";

//backgroundColor: "yellow",

export interface Worker {
  fullName: string;
  shifts: { start: number; end: number; startLabel: string; endLabel: string }[];
}

interface Shift {
  start: number; // in minutes
  end: number;   // in minutes
}

function timeToMinutes(time: string, isEndTime = false): number {
  const match = time.trim().match(/^(\d{1,2}):(\d{2})\s?(AM|PM)$/i);
  if (!match) throw new Error("Invalid time format");
  const [, hh, mm, period] = match;
  let hours = parseInt(hh, 10);
  const minutes = parseInt(mm, 10);
  if (period === "AM") {
    if (hours === 12) hours = 0;
  } else {
    if (hours !== 12) hours += 12;
  }
  let totalMinutes = hours * 60 + minutes;
  if (isEndTime && totalMinutes === 0) totalMinutes = 24 * 60;
  return totalMinutes;
}

export default function DailyGraphComponent({ setHeight }) {
  const rowRefs = useRef<HTMLDivElement[]>([]);
  const [headerHeight, setHeaderHeight] = useState(0);
  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);
  const headerRef = useRef<HTMLDivElement | null>(null);

  // --- Root font size for rem conversion ---
  const rootFontSize = parseFloat(getComputedStyle(document.documentElement).fontSize); // in px


  // --- Constants in rem ---
  const SEGMENT_WIDTH = 0.875 * rootFontSize;       // 14px
  const ROW_HEIGHT = 1.0625 * rootFontSize;         // 17px
  const GRID_ROW_HEIGHT = 1.1875 * rootFontSize;    // 19px
  const STRIPE_COUNT = 11;

  const GRID_HEIGHT = GRID_ROW_HEIGHT * STRIPE_COUNT;
  const LEFT_OFFSET = 1.5625 * rootFontSize;        // 25px
  const HEADER_LEFT = 27.5 * rootFontSize;         // 90px
  const HOVER_LEFT = 27 * rootFontSize;              // 80px

  const LEFT_COL_LEFT = -13.6875 * rootFontSize;    // -219px
  const LEFT_COL_NAME = 13.75 * rootFontSize;       // 220px
  const LEFT_COL_TIME = 3.75 * rootFontSize;        // 60px

  const STRIPE_LEFT = 0 * rootFontSize;      // -315px
  const STRIPE_WIDTH = 115 * rootFontSize;     // 1797px
  const STRIPE_TOP_OFFSET = -.95 * rootFontSize;   // 50px

  const EVENT_LEFT_OFFSET = 0.1 * rootFontSize;  // -6px
  const EVENT_TOP_OFFSET = .4 * rootFontSize;    // 54.77px
  const EVENT_HEIGHT = GRID_ROW_HEIGHT - 0.3125 * rootFontSize; // 19-5
  const TOTAL_WIDTH_OF_GRID = 84.5 * rootFontSize;
  const TOTAL_WIDTH_OF_PAGE = 94.0 * rootFontSize;
  const LEFT_POSITION_OF_LABELS = 2;  // px



  // Tooltip
  const [tooltip, setTooltip] = useState<{ visible: boolean; text: string; x: number; y: number }>({
    visible: false,
    text: "",
    x: 0,
    y: 0,
  });

  if (!ctx) throw new Error("DailyGraphComponent must be used within CalendarContext.Provider");
  if (!rulesCtx) throw new Error("DailyGraphComponent must be used within CalendarContext.Provider");

  const { users, selectedDate } = ctx;
  const usersForDate: User[] = selectedDate ? users.filter((u) => u.date === selectedDate) : [];

  const workers: Worker[] = usersForDate.map((user) => ({
    fullName: user.fullName,
    shifts: user.shifts.map((shift) => ({
      start: timeToMinutes(shift.startShift),
      end: timeToMinutes(shift.endShift, true),
      startLabel: shift.startShift,
      endLabel: shift.endShift,
    })),
  }));

    useEffect(() => {
    const el = document.querySelector(`.${styles.nameCell}`);
    if (!el) return;

    const cs = getComputedStyle(el);
    console.log("nameCell font-size:", cs.fontSize);
    console.log("font-family:", cs.fontFamily);
    console.log("letter-spacing:", cs.letterSpacing);
  }, []);


  useEffect(() => {
  const header = headerRef.current;
  if (!header) return;
  
  const observer = new ResizeObserver(entries => {
    for (const entry of entries) {
      setHeight(entry.contentRect.height);
    }
  });
  
  observer.observe(header);
  return () => observer.disconnect();
}, [setHeight]);

  
  function getShift(startMinutes: number, endMinutes: number) {
    const startQuarters = startMinutes / 15;
    const endQuarters = endMinutes / 15;
    const rawLeft = startQuarters * SEGMENT_WIDTH + HEADER_LEFT;
    const rawRight = endQuarters * SEGMENT_WIDTH + HEADER_LEFT - 1;
    const width = Math.max(1, rawRight - rawLeft);
    return { left: rawLeft, width };
  }

  const formatHour = (hour: number) => {
    if (hour === 24) return "12 AM";
    if (hour === 25) return "1 AM";
    const period = hour < 12 ? "AM" : "PM";
    const hr12 = hour % 12 === 0 ? 12 : hour % 12;
    return `${hr12} ${period}`;
  };

  
const renderLabels = () => (
  <>
  {/* <div className = {styles.labelsContainer}> */}
    {/* Column 1: totalLeftOffset */}
    <div className={styles.totalLeftOffset} style={{ backgroundColor: "yellow", gridColumn: 1, gridRow: 1, position: "sticky", top: 0, zIndex: 100000 }}>1</div>
    <div style={{ gridColumn: 2, gridRow: 1, backgroundColor: "white", position: "sticky" , top:0, zIndex: 100000}}>2</div>
    {/* Column 2: Daily Hours */}
    <div className={styles.totalHours} style={{ gridColumn: 3, gridRow: 1, backgroundColor: "yellow" , position: "sticky",zIndex: 100000, top:0 }}>
      <div>Daily</div>
      <div>Hours</div>
    </div>
    <div style={{ gridColumn: 4, gridRow: 1, backgroundColor: "white", position: "sticky" , top:0}}></div>

    {/* Column 3: Timeline labels */}
    <div className={styles.labelsTimeline} style={{ gridColumn: 5, gridRow: 1, position: "sticky", width: `21rem`, top: 0 }}>
  
  
 {Array.from({ length: 25 }, (_, index) => {
  const hour = index;
  const leftPos = hour * 4 * SEGMENT_WIDTH;
  const leftRem = leftPos / rootFontSize - 1.4

  return (
    <React.Fragment key={hour}>
      {/* Yellow background bar */}
      <div
        style={{
          position: "absolute",
          left: `${leftRem}rem`,
          top: 0,
          width: `${(4 * SEGMENT_WIDTH) / rootFontSize}rem`, // width of one hour
          height: "3rem",
          backgroundColor: "yellow",
          zIndex: 1,
        }}
      />
      
      {/* Hour label (on top of yellow) */}
      <div
        className={styles.headerLabel}
        style={{
          position: "absolute",
          left: `${leftRem}rem`,
          top: 0,
          zIndex: 21,
        }}
      >
        {formatHour(hour)}
      </div>
    </React.Fragment>
  );
})}
</div>
{/* </div> */}
  </>
);

  function calculateTotalHours(shifts: Shift[]): string {
    const totalMinutes = shifts.reduce((sum, shift) => sum + (shift.end - shift.start), 0);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
  }

  const renderLeftColumn = () => (
    <div className={styles.leftColumnOverlay} >
      {workers.map((user, rowIndex) => (
        <div
          key={rowIndex}
          style={{
            position: "absolute",
            top: `${(rowIndex * GRID_ROW_HEIGHT - 49) / rootFontSize}rem`,
            left: 0,
            height: `${GRID_ROW_HEIGHT / rootFontSize}rem`,
            display: "grid",
            gridTemplateColumns: `18rem 3rem 3rem`,
            zIndex: 5000,
          }}
        >
          {/* Column 1: Name */}
          <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            // paddingRight: "1rem"
          }}>
            <div className={styles.nameCell}>{user.fullName}</div>
          </div>
          
          {/* Column 2: Spacer */}
          <div></div>
          
          {/* Column 3: Daily Hours */}
          <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}>
            <div className={styles.timeCell}>{calculateTotalHours(user.shifts)}</div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderTimeGrid = () => {
  return (
    <div
      className={styles.timeGrid}
      style={{
        position: "absolute",
        top: `${STRIPE_TOP_OFFSET / rootFontSize}rem`,
        left: `${HEADER_LEFT / rootFontSize}rem`,
        width: `${TOTAL_WIDTH_OF_GRID / rootFontSize}rem`,
        // ← Just subtract yellow header (3rem), not 5rem
        // height: `calc(100vh - 3rem)`, 
        // minHeight: `${GRID_ROW_HEIGHT * 11 / rootFontSize}rem`,
        height: `calc(100vh - 5rem)`,  // ← Fixed height to viewport
        minHeight: `${GRID_ROW_HEIGHT * workers.length / rootFontSize}rem`,
        
        backgroundImage: `
          repeating-linear-gradient(
            to right,
            #9ca3af 0,
            #9ca3af ${2 / rootFontSize}rem,
            transparent ${2 / rootFontSize}rem,
            transparent ${SEGMENT_WIDTH * 4 / rootFontSize}rem
          ),
          repeating-linear-gradient(
            to right,
            rgba(156,163,175,0.45) 0,
            rgba(156,163,175,0.45) ${1 / rootFontSize}rem,
            transparent ${1 / rootFontSize}rem,
            transparent ${SEGMENT_WIDTH / rootFontSize}rem
          )
        `,
        backgroundRepeat: "repeat",
        backgroundSize: "auto 100%",
        pointerEvents: "none",
        zIndex: 16,
      }}
    />
  );
};

  const renderHourHoverLayer = () => (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: `${TOTAL_WIDTH_OF_GRID / rootFontSize}rem`,
        height: `calc(100vh - 5rem - ${GRID_ROW_HEIGHT / rootFontSize}rem)`,
        zIndex: 19,
      }}
    >
      {Array.from({ length: 25 }).map((_, hour) => {
        const x = hour * 4 * SEGMENT_WIDTH;
        return (
          <div
            key={hour}
            style={{
              position: "absolute",
              left: `${(x + HOVER_LEFT) / rootFontSize}rem`,
              top: 0,
              width: `${20 / rootFontSize}rem`,
              height: "100%",
              background: "transparent",
              cursor: "pointer",
            }}
            onMouseEnter={(e) =>
              setTooltip({ visible: true, text: formatHour(hour), x: e.clientX, y: e.clientY })
            }
            onMouseLeave={() => setTooltip({ visible: false, text: "", x: 0, y: 0 })}
          />
        );
      })}
    </div>
  );

  const renderStripes = (rowHeight: number, totalWidth: number) => {
    return Array.from({ length: STRIPE_COUNT }, (_, rowIndex) => {
      const top = rowIndex * rowHeight + STRIPE_TOP_OFFSET;
      const backgroundColor = rowIndex % 2 === 0 ? "#f0f0f0" : "#e0e0e0";
      return (
        <div
          key={`stripe-${rowIndex}`}
          className={styles.highliteRow}
          style={{
            top: `${top / rootFontSize}rem`,
            backgroundColor,
            left: `${STRIPE_LEFT / rootFontSize}rem`,
            width: `${STRIPE_WIDTH / rootFontSize}rem`,
            height: `${rowHeight / rootFontSize}rem`,
            zIndex: 1,
          }}
        />
      );
    });
  };

  const renderEventBars = () => (
    <>
      <div ref={headerRef} className={styles.headerFixed}>
        <Header />
      </div>

      <div className={styles.eventBarsContainer} style={{ position: "relative" }}>
        {renderStripes(GRID_ROW_HEIGHT, TOTAL_WIDTH_OF_GRID)}
        {workers.map((user, rowIndex) =>
          user.shifts.map((shift, i) => {
            const { left, width } = getShift(shift.start, shift.end);
            const top = rowIndex * GRID_ROW_HEIGHT + EVENT_TOP_OFFSET;
            const tooltipText = `${user.fullName}\n${shift.startLabel} - ${shift.endLabel}`;
            return (
              <div
                key={`event-${rowIndex}-${i}`}
                className={styles.eventBar}
                style={{
                  position: "absolute",
                  top: `${top / rootFontSize}rem`,
                  left: `${(left + EVENT_LEFT_OFFSET) / rootFontSize}rem`,
                  width: `${width / rootFontSize}rem`,
                  height: `${EVENT_HEIGHT / rootFontSize}rem`,
                }}
                onMouseEnter={(e) =>
                  setTooltip({ visible: true, text: tooltipText, x: e.clientX, y: e.clientY - 30 })
                }
                onMouseLeave={() => setTooltip({ visible: false, text: "", x: 0, y: 0 })}
              />
            );
          })
        )}
      </div>
    </>
  );

  const renderEmployeeSummaryGrid = () => (
    
    <div style={{
      marginTop: "2rem",
      
      paddingTop: "1rem",
      display: "grid",
      gridTemplateColumns: "20rem 3rem 3rem",
      gap: 0,
      width: "26rem"
    }}>
      {workers.map((worker, rowIndex) => (
        <React.Fragment key={rowIndex}>
          <div style={{
            height: `${GRID_ROW_HEIGHT / rootFontSize}rem`,
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            paddingRight: "1rem",
            backgroundColor: rowIndex % 2 === 0 ? "#f0f0f0" : "#e0e0e0"
          }}>
            {worker.fullName}
          </div>
          
          <div style={{
            height: `${GRID_ROW_HEIGHT / rootFontSize}rem`,
            backgroundColor: rowIndex % 2 === 0 ? "#f0f0f0" : "#e0e0e0"
          }}></div>
          
          <div style={{
            height: `${GRID_ROW_HEIGHT / rootFontSize}rem`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgb(255, 153, 0)",
            fontWeight: "bold"
          }}>
            {calculateTotalHours(worker.shifts)}
          </div>
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <div className={styles.pageWrapper}>
      <div className={styles.titleContainer}>
        {workers.length > 0 && (
          <div className={styles.dailyWrapper}>
            <div className={styles.dateHeading} style={{ visibility: selectedDate ? "visible" : "hidden" }} />
          </div>
        )}
      </div>



<div className={styles.container}>
  {/* Top row: labels */}
  
  
  {/* <div className = {styles.labels} style={{ gridColumn: "2 / 4", gridRow: 1, minWidth: `${TOTAL_WIDTH_OF_GRID / rootFontSize}rem`  }}> */}
    {renderLabels()}
  {/* </div> */}
 

  {/* Left column: employee names & daily hours */}
  

  
  
  {/* Bottom row: timeline scroll area */}
  <div className={styles.scrollArea} >
  {/* <div className = {styles.stickeyHeader}> */}
  <div className={styles.timelineContainer}




    style={{
      position: "relative",
      width: `${TOTAL_WIDTH_OF_GRID / rootFontSize}rem`,
      
    }}
  >

     <div
     // style={{
     //   position: "absolute",
     //   /*!!!!Needs to be negative*/
     //   top: `${-4}rem`,
     //   left: 0,
     //   width: "115rem",        /* ← matches timelineContainer width exactly */
     //   height: "3rem",
     //   // backgroundColor: "yellow",
     //   zIndex: 19,
    // }}
    ></div>

    
    {renderLeftColumn()}
    

    {/* SCROLLING CONTENT */}
    {renderTimeGrid()}
    {renderHourHoverLayer()}
    {renderEventBars()}
  </div>
{/* </div> */}
</div>

</div>

      {/* NEW EMPLOYEE SUMMARY GRID BELOW MAIN CONTAINER */}
      {/* {renderEmployeeSummaryGrid()} */}

      {tooltip.visible && (
        <div className={styles.tooltip} style={{ left: `${tooltip.x / rootFontSize}rem`, top: `${tooltip.y / rootFontSize}rem` }}>
          {tooltip.text.split("\n").map((line, i) => (
            <div key={i}>{line}</div>
          ))}
        </div>
      )}
    </div>
  );
}
