import { contextBridge, ipcRenderer } from "electron";
console.log("preload.ts loaded.");
// /* ----------------------------------------------------
//  * Types (matches IPC + DB exactly)
//  * ---------------------------------------------------- */
// export interface ScheduleData {
//   users: unknown[];
//   rules: unknown[];
//   firstDayOfYear?: string;
//   lastDayOfYear?: string;
//   [key: string]: unknown;
// }
// /* ----------------------------------------------------
//  * API interfaces
//  * ---------------------------------------------------- */
// interface SchedulesApi {
//   listSchedules(): Promise<string[]>;
//   getSchedule(name: string): Promise<ScheduleData | null>;
//   saveSchedule(name: string, schedule: ScheduleData): Promise<void>;
//   deleteSchedule(name: string): Promise<void>;
// }
// interface ZoomApi {
//   setZoom(factor: number): Promise<number>;
//   getZoom(): Promise<number>;
// }
// interface Api {
//   schedules: SchedulesApi;
//   zoomAPI: ZoomApi;
// }
/* ----------------------------------------------------
 * Preload implementation
 * ---------------------------------------------------- */
const api = {
    schedules: {
        listSchedules() {
            return ipcRenderer.invoke("schedules:list");
        },
        getSchedule(name) {
            return ipcRenderer.invoke("schedules:get", name);
        },
        saveSchedule(name, schedule) {
            return ipcRenderer.invoke("schedules:save", name, {
                users: schedule.users ?? [],
                rules: schedule.rules ?? [],
                firstDayOfYear: schedule.firstDayOfYear ?? "",
                lastDayOfYear: schedule.lastDayOfYear ?? "",
            });
        },
        deleteSchedule(name) {
            return ipcRenderer.invoke("schedules:delete", name);
        },
    },
    zoomAPI: {
        async setZoom(factor) {
            return ipcRenderer.invoke("set-zoom", factor);
        },
        async getZoom() {
            return ipcRenderer.invoke("get-zoom");
        },
    },
};
// Expose to renderer
contextBridge.exposeInMainWorld("api", api);
