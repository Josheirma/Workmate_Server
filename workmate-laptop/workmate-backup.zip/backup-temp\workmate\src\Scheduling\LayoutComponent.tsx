import React from "react";
import { Outlet } from "react-router-dom";
//import styles from "./HeaderComponent.module.css";

export const LayoutComponent: React.FC = () => {
  return (
    <>
      
      <main style={{ padding: "0px" }}>
        <Outlet /> {/* child routes will render here */}
      </main>
    </>
  );
}