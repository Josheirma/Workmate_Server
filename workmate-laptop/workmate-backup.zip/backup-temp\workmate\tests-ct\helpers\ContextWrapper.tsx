import { ReactNode } from "react"
import { CalendarContext } from "../../src/Scheduling/CalendarContext"

type CtxType = React.ContextType<typeof CalendarContext>

interface Props {
  ctx: CtxType
  children: ReactNode
}

export function ContextWrapper({ ctx, children }: Props) {
  return (
    <CalendarContext.Provider value={ctx}>
      {children}
    </CalendarContext.Provider>
  )
}
