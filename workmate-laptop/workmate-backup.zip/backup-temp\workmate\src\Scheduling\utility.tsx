// utility.ts
import { CalendarContextType } from "./CalendarContext"; // adjust types to your app
import { RulesContextType } from "./MakeRulesContext";

export function loadFromLocalStorage(ctx: CalendarContextType, rulesCtx: RulesContextType, ) {
  try {
    const saved = localStorage.getItem("calendarContext");
    if (!saved) return;

    const prev = JSON.parse(saved) ?? {};

    
    const storedUsers = Array.isArray(prev.users) ? prev.users : [];
    const storedRules = Array.isArray(prev.rules) ? prev.rules : [];
    

    // Put them back into context (do not overwrite if ctx is undefined)
    if (ctx?.setUsers) ctx.setUsers(storedUsers);
    

    if (rulesCtx?.setRules) rulesCtx.setRules(storedRules);

    // If your CalendarContext tracks selectedDate in storage, you can also restore it:
    if (typeof prev.selectedDate === "string" && ctx?.setSelectedDate) {
      ctx.setSelectedDate(prev.selectedDate);
    }

    if (typeof prev.firstDayOfYear === "string" && ctx?.setFirstDayOfYear) {
      ctx.setFirstDayOfYear(prev.firstDayOfYear);
    }

    if (typeof prev.lastDayOfYear === "string" && ctx?.setLastDayOfYear) {
      ctx.setLastDayOfYear(prev.lastDayOfYear);
    }

    if (typeof prev.scheduleName === "string" && ctx?.setScheduleName) {
      ctx.setScheduleName(prev.scheduleName);
    }

  } catch (err) {
    console.error("loadFromLocalStorage failed:", err);
  }
}
