import { Request, Response } from "express"
import { generateOnlineSerial } from "../utils/serial"

export async function purchaseSerial(req: Request, res: Response) {
  const { email } = req.body

  if (!email)
    return res.json({ success: false, error: "email required" })

  // basic email format check
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.json({ success: false, error: "invalid email" })

  try {
    // assume payment verified before this point
    const serial = await generateOnlineSerial(email)

    // TODO: plug in your email service here
    // await sendEmail(email, serial)

    res.json({
      success: true,
      message: "Serial sent to your email"
    })

  } catch (err) {
    console.error(err)
    res.json({ success: false, error: "purchase failed" })
  }
}