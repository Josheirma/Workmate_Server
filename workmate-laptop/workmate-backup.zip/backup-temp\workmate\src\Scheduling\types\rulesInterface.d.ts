import type { Dispatch, SetStateAction } from "react";
export interface RulesUser {
    userID1: string;
    userID2: string;
    fullName1: string;
    fullName2: string;
    isRestricted: boolean;
}
export interface RulesContextType {
    rules: RulesUser[];
    setRules: Dispatch<SetStateAction<RulesUser[]>>;
}
