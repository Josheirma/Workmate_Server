import React, { useState, ReactNode } from "react";
import { CalendarContext, CalendarContextType, User } from "./CalendarContext";




interface CalendarProviderProps {
  children: ReactNode;
}

type ToastState = {
  message: string;
  type: "error" | "info";
} | null;


export const CalendarProvider: React.FC<CalendarProviderProps> = ({ children }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  // Scheduling range
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);
  
  // Year range
  const [firstDayOfYear, setFirstDayOfYear] = useState<string | null>(null);
  const [lastDayOfYear, setLastDayOfYear] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState>(null);
  const [scheduleName, setScheduleName] = useState<string>("");




  const value: CalendarContextType = {
    
    users,
    setUsers,
    selectedDate,
    setSelectedDate,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    firstDayOfYear,
    setFirstDayOfYear,
    lastDayOfYear,
    setLastDayOfYear,
    toast,
    setToast,
    scheduleName,
    setScheduleName
  };

  return <CalendarContext.Provider value={value}>{children}</CalendarContext.Provider>;
};
