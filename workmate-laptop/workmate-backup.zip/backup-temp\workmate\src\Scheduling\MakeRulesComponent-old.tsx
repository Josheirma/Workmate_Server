import React, { useContext, useState, useEffect } from "react";
import { CalendarContext, User } from "./CalendarContext";
import { RulesContext, RulesUser } from "./MakeRulesContext";
import styles from "./MakeRulesComponent.module.css";
import { loadFromLocalStorage } from "./utility";
import ToastContainer from "./ToastContainer";
import { useToast } from "./useToast";
 

export default function MakeRulesComponent() {
  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);

  if (!ctx) {
    throw new Error("MakeRulesComponent must be used within CalendarContext.Provider");
  }
  if (!rulesCtx) {
    throw new Error("MakeRulesComponent must be used within RulesContext.Provider");
  }

  const { users, selectedDate } = ctx;
  const { rules, setRules } = rulesCtx;
  const { toasts, showToast } = useToast();

  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [selectedRuleUsers, setSelectedRuleUsers] = useState<{ user1?: User; user2?: User }>({});

  

  
  useEffect(() => {
    loadFromLocalStorage(ctx, rulesCtx);
    
  }, []);

  

  const allUsers: User[] = selectedDate ? users.filter((u) => u.date === selectedDate) : [];

  const saveRulesToLocalStorage = (newRulesArray: RulesUser[]) => {
    try {
      const saved = localStorage.getItem("calendarContext");
      const prev = saved ? JSON.parse(saved) : {};

      localStorage.setItem(
        "calendarContext",
        JSON.stringify({
          ...prev,               // ✅ preserve all existing keys
          rules: newRulesArray,  // ✅ overwrite only rules
        })
      );
    } catch (err) {
      console.error("saveRulesToLocalStorage error:", err);
    }
  };

  const handleSelect = (index: number) => {
    const user = allUsers[index];
    setSelectedIndices((prev) => {
      if (prev.includes(index)) {
        setSelectedRuleUsers((prevRuleUsers) => {
          const newRuleUsers = { ...prevRuleUsers };
          if (newRuleUsers.user1?.userID === user.userID) newRuleUsers.user1 = undefined;
          if (newRuleUsers.user2?.userID === user.userID) newRuleUsers.user2 = undefined;
          return newRuleUsers;
        });
        return prev.filter((i) => i !== index);
      }

      if (prev.length < 2) {
        setSelectedRuleUsers((prevRuleUsers) => {
          if (!prevRuleUsers.user1) return { ...prevRuleUsers, user1: user };
          if (!prevRuleUsers.user2) return { ...prevRuleUsers, user2: user };
          return prevRuleUsers;
        });
        return [...prev, index];
      }

      return prev;
    });
  };

  const handleAddRule = () => {
    const { user1, user2 } = selectedRuleUsers;

    if (!user1 || !user2) {
      showToast("❌ Select exactly two users to create a rule!");
      return;
    }

    if (user1.userID === user2.userID) {
      showToast("❌ You cannot create a rule with the same user twice!");
      return;
    }

    // Ensure consistent alphabetical order by userID
    const [first, second] = user1.userID < user2.userID ? [user1, user2] : [user2, user1];

    // Create a new RulesUser object
    const newRule: RulesUser = {
      userID1: first.userID,
      firstName1: first.firstName,
      lastName1: first.lastName,
      userID2: second.userID,
      firstName2: second.firstName,
      lastName2: second.lastName,
    };

    // Add to RulesContext
    const newRulesArray = [...rules, newRule];
    setRules(newRulesArray);

    // Reset selection
    setSelectedRuleUsers({});
    setSelectedIndices([]);

    // Save to localStorage (consistent key names)
    saveRulesToLocalStorage(newRulesArray);
  };

  const handleDeleteRule = (ruleIndex: number) => {
    const newRulesArray = rules.filter((_, idx) => idx !== ruleIndex);
    setRules(newRulesArray);
    saveRulesToLocalStorage(newRulesArray);
  };

  return (
    <div className={styles.pageWrapper}>
      <div className={styles.container}>
        <div className={styles.contentRow}>
          {/* Users List */}
          <div className={styles.userContainer}>
            <h3>Users</h3>
            <div className={styles.list}>
              {allUsers.length === 0 ? (
                <div className={styles.empty}>No users available</div>
              ) : (
                allUsers.map((user, idx) => {
                  const isSelected = selectedIndices.includes(idx);
                  return (
                    <div
                      key={user.userID}
                      className={`${styles.item} ${isSelected ? styles.selected : ""}`}
                      onClick={() => handleSelect(idx)}
                    >
                      {user.firstName} {user.lastName}
                    </div>
                  );
                })
              )}
            </div>
            <div className={styles.buttonContainer}>
              <button className={styles.addRuleBtn} onClick={handleAddRule}>
                Add "Cannot Work Together" Rule
              </button>
            </div>
          </div>

          {/* Rules List */}
          <div className={styles.rulesContainer}>
            <h3>Rules</h3>
            <div className={styles.rulesList}>
              {rules.length === 0 ? (
                <div className={styles.empty}>No rules yet</div>
              ) : (
                rules
                  .slice()
                  .sort((a, b) => (a.firstName1 + a.lastName1).localeCompare(b.firstName1 + b.lastName1))
                  .map((rule, idx) => (
                    <div key={idx} className={styles.ruleItem}>
                      {rule.firstName1} {rule.lastName1} cannot work with {rule.firstName2} {rule.lastName2}
                      <button className={styles.deleteBtn} onClick={() => handleDeleteRule(idx)}>
                        ❌
                      </button>
                    </div>
                  ))
              )}
            </div>
          </div>
        </div>
      </div>
      <ToastContainer toasts={toasts} />
    </div>
  );
}
