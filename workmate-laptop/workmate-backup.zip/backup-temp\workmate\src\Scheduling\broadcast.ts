export const logoutBC =
  typeof window !== "undefined" &&
  "BroadcastChannel" in window &&
  typeof BroadcastChannel === "function"
    ? new BroadcastChannel("app-calendar")
    : null;