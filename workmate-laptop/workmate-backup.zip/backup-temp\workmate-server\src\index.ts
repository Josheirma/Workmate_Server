import express   from "express"
import helmet    from "helmet"
import morgan    from "morgan"
import dotenv    from "dotenv"
import { activateLicense }         from "./routes/activate"
import { purchaseSerial }          from "./routes/purchase"
import { activateLimiter }         from "./middleware/rateLimit"
import { validateActivationInput } from "./middleware/validate"

const result = dotenv.config()
console.log("DOTENV RESULT:", result)
console.log("DATABASE_URL:", process.env.DATABASE_URL)

const app = express()

app.use(helmet())
app.use(morgan("combined"))
app.use(express.json())

// routes
app.post("/activate", activateLimiter, validateActivationInput, activateLicense)
app.post("/purchase", purchaseSerial)

const PORT = Number(process.env.PORT) || 3000

const server = app.listen(PORT, () => {
  console.log(`Workmate server running on port ${PORT}`)
})

server.on("error", (err: any) => {
  if (err.code === "EADDRINUSE") {
    console.log(`Port ${PORT} in use, trying ${PORT + 1}...`)
    server.listen(PORT + 1)
  }
})