import React from "react";
import { Outlet } from "react-router-dom";
import styles from "./Test.module.css";
import { Header1 } from './Header1';

export function Test() {
  return (
    <>
    <Header1/>
      <div className = {styles.page}>
      
      <div className= {styles.box}>
        TEST2
      </div>
      </div>
    </>
  );
}