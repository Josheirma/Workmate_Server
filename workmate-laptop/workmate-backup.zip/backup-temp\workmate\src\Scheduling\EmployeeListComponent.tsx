import React, { useContext, useState, useRef, useEffect, useMemo } from "react";
import { CalendarContext, User, Shift } from "./CalendarContext";
import { RulesContext, RulesUser } from "./MakeRulesContext";
import { TimeInput } from "./TimeInput";
import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
import styles from "./EmployeeListComponent.module.css";
import classNames from "classnames";
import ToastContainer from "./ToastContainer";
import { useToast } from "./useToast";

import { saveScheduleToDB } from "../db/saveSchedule";


export default function EmployeeListComponent({ height }: { height: number }) {
  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);
  const [headerHeight, setHeaderHeight] = useState(0);
  

  if (!ctx) throw new Error("EmployeeListComponent must be used within CalendarContext.Provider");
  if (!rulesCtx) throw new Error("EmployeeListComponent must be used within RulesContext.Provider");

  const { setUsers, users: ctxUsers, selectedDate, firstDayOfYear, lastDayOfYear, scheduleName} = ctx;
  const { rules} = rulesCtx;
  const { toasts, showToast } = useToast();

  const users = useMemo(() => ctxUsers ?? [], [ctxUsers]);

  const [fullName, setFullName] = useState("");
  
  const [timeStart, setTimeStart] = useState("");
  const [timeEnd, setTimeEnd] = useState("");

  // ✅ allow MULTIPLE entries selected
  // ✅ only allow "Set Shift" when EXACTLY ONE entry is selected
  const [selectedEmployeeIDs, setSelectedEmployeeIDs] = useState<Set<string>>(new Set());

  const [restrictedUserIDs, setRestrictedUserIDs] = useState<Set<string>>(new Set());
  const [restrictedPairs, setRestrictedPairs] = useState<[string, string][]>([]);
  

  const measureRef = useRef<HTMLSpanElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [clipboardUsers, setClipboardUsers] = useState<ClipboardUser[]>([]);
  //const MAX_CHARS = 17;
  const nameInputRef = useRef<HTMLInputElement>(null);
  const NAME_MAX_WIDTH_REM = 13; // match your LEFT_COL_NAME rem value
  const nameMeasureRef = useRef<HTMLDivElement | null>(null);
  
  type ClipboardUser = Omit<User, "date" | "shifts"> & {
  
  shifts?: Shift[];
};

// hidden measurement element (once)
useEffect(() => {
  const el = document.createElement("div");
  el.className = styles.nameCell;  // same as display
  el.style.position = "absolute";
  el.style.visibility = "hidden";
  el.style.whiteSpace = "nowrap";
  el.style.pointerEvents = "none";
  el.style.left = "-9999px";

  document.body.appendChild(el);
  nameMeasureRef.current = el;

  return () => {
    document.body.removeChild(el);
  };
}, []);

  useEffect(() => {
    document.documentElement.style.setProperty(
      "--header-height",
      `${height}px`
      
    );
    console.log("header: ", height)
  }, [height]);

// useEffect(() => {
//     const header = headerRef.current;
//     if (!header) return;
//     const observer = new ResizeObserver(entries => {
//       for (const entry of entries) {
//         setHeaderHeight(entry.contentRect.height);
//       }
//     });
//     observer.observe(header);
//     document.documentElement.style.setProperty(
//     "--header-height",
//     `${px}px`
//   );
//     return () => observer.disconnect();
//   }, []);
  
  

  // ✅ clear selection when date changes
  useEffect(() => {
    setSelectedEmployeeIDs(new Set());
  }, [selectedDate]);

  // ------------------------------
  // Derived current employee list for the selected date
  // ------------------------------
  const employeeList = useMemo(
    () => (selectedDate ? users.filter((u) => u.date === selectedDate) : []),
    [users, selectedDate]
  );

  // ------------------------------
  // Restricted Pairs Helpers (global rules, apply when both users on current date)
  // ------------------------------
  const updateRestrictedStatus = (currentUsers: User[], rulesArr: RulesUser[]) => {
    const userIDs = new Set(currentUsers.map((u) => u.userID));
    const usersForSelectedDate = users.filter(u => u.date === selectedDate);
    const userIDsForDate = new Set(usersForSelectedDate.map(u => u.userID));
    const pairs: [string, string][] = [];

    rulesArr.forEach((r) => {
      if (userIDs.has(r.userID1) && userIDs.has(r.userID2)) {
        pairs.push([r.userID1, r.userID2]);
       
      }
    });

    setRestrictedPairs(pairs);

    // set of all users involved in any active pair on this date
    const ids = new Set<string>();
    pairs.forEach(([a, b]) => {
      ids.add(a);
      ids.add(b);
    });
    setRestrictedUserIDs(ids);

    // Process only rules for the selected date first
  // rules.forEach(r => {
  // // Check if both users in the rule are present in users for selected date
  // if (userIDsForDate.has(r.userID1) && userIDs.has(r.userID2)) {
  //   r.isRestricted = true;
  //   }
  // });
   };

  // recompute whenever employeeList OR rules change
  useEffect(() => {
    updateRestrictedStatus(employeeList, rules);
  }, [employeeList, rules]);

  const areRestrictedUsersInContainer = () => {
    return restrictedPairs.length > 0;
  };

  const isEmployeeFullyRestricted = (u: User) => {
    return restrictedUserIDs.has(u.userID);
  };

  // ------------------------------
  // Shift & Time Helpers
  // ------------------------------
  function toMinutes(time: string, isEndTime = false): number {
    const match = time.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (!match) return NaN;
    let hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    const period = match[3].toUpperCase();
    if (period === "AM") {
      if (hours === 12) hours = 0;
    } else {
      if (hours !== 12) hours += 12;
    }
    let totalMinutes = hours * 60 + minutes;
    if (isEndTime && totalMinutes === 0) totalMinutes = 24 * 60;
    return totalMinutes;
  }

  const shiftsOverlap = (a: Shift, b: Shift) => {
    const aStart = toMinutes(a.startShift, false);
    const aEnd = toMinutes(a.endShift, true);
    const bStart = toMinutes(b.startShift, false);
    const bEnd = toMinutes(b.endShift, true);
    return aStart < bEnd && bStart < aEnd;
  };

  const doShiftsOverlap = (user: User, newShift: Shift) => {
    const overlap = (user.shifts ?? []).some((s) => shiftsOverlap(newShift, s));
    if (overlap) {
      showToast(`❌ This shift overlaps with an existing shift, try again!`);
      return true;
    }
    return false;
  };

  const isShiftValid = (startShift: string, endShift: string) => {
    if (!startShift && !endShift) return true;
    const startMinutes = toMinutes(startShift, false);
    const endMinutes = toMinutes(endShift, true);
    if (isNaN(startMinutes) || isNaN(endMinutes)) return false;
    const withinDay = startMinutes >= 0 && startMinutes < 1440 && endMinutes > 0 && endMinutes <= 1440;
    const correctOrder = endMinutes > startMinutes;
    if (withinDay && correctOrder) return true;
    showToast(`❌ Invalid shifts, try again!`);
    return false;
  };

  // const fitsInRow = (fullName : string) => {
  //   if (!measureRef.current) return true;
  //   measureRef.current.textContent = `${fullName}`;
  //   return measureRef.current.offsetWidth < 350;
  // };

  // ------------------------------
  // User CRUD
  // ------------------------------
  const addUser = (user: User) => {
    let newUsers: User[] = [];
    setUsers((prev) => {
      newUsers = [...prev, user];

      return newUsers;
    });
    
  };

  const updateUser = (index: number, updatedUser: User) => {
    let newUsers: User[] = [];
    setUsers((prev) => {
      newUsers = prev.map((u, i) => (i === index ? { ...updatedUser } : u));

      return newUsers;
    });
    
  };

  const deleteUser = (userID: string) => {
    const newUsers = users.filter((u) => !(u.userID === userID && u.date === selectedDate));

    // recompute restrictions
    updateRestrictedStatus(newUsers.filter((u) => u.date === selectedDate), rules);

    // ✅ if deleted user was selected, unselect
    setSelectedEmployeeIDs((prev) => {
      const next = new Set(prev);
      next.delete(userID);
      return next;
    });

    setUsers(newUsers);
    
  };

  const checkNewUserRuleViolations = (newUser: User, employeeListArg: User[], rulesArr: RulesUser[]): boolean => {
    for (const other of employeeListArg) {
      if (newUser.userID === other.userID) continue;
      const matchedRule = rulesArr.find(
        (r) =>
          (r.userID1 === newUser.userID && r.userID2 === other.userID) ||
          (r.userID2 === newUser.userID && r.userID1 === other.userID)
      );
      if (matchedRule) {
      const user1Name =
        matchedRule.userID1 === newUser.userID
          ? matchedRule.fullName1
          : matchedRule.fullName2;

      const user2Name =
        matchedRule.userID1 === newUser.userID
          ? matchedRule.fullName2
          : matchedRule.fullName1;

      showToast(
        `Rule violation:\n\n${user1Name} ❌ cannot work with ❌ ${user2Name}!`
      );
  return true;
}

    return false;
  };
}

  const handleAddEmployee = () => {
    //if (!selectedDate || !firstName.trim() || !lastName.trim()) return;
    if (!isShiftValid(timeStart, timeEnd)) return;

    const nameExists = users.some(
      (u) =>
        u.date === selectedDate &&
        u.fullName.trim().toLowerCase() === fullName.trim().toLowerCase() 
        
    );
    if (nameExists) {
      showToast("❌ An employee with the same name already exists!");
      return;
    }

    
    

    const newUser: User = {
      userID: fullName.trim(),
      fullName: fullName.trim(),
      
      shifts: timeStart && timeEnd ? [{ startShift: timeStart, endShift: timeEnd }] : [],
      date: selectedDate,
    
    };

    if (checkNewUserRuleViolations(newUser, employeeList, rules)) return;
    addUser(newUser);

    setFullName("");
    
    setTimeStart("");
    setTimeEnd("");
  };

  const handleSetShift = () => {
    if (!isShiftValid(timeStart, timeEnd)) return;

    // ✅ only allow set shift if EXACTLY ONE entry is selected
    if (selectedEmployeeIDs.size !== 1) return;

    const [onlyID] = Array.from(selectedEmployeeIDs);
    const userFromList = employeeList.find((u) => u.userID === onlyID);
    if (!userFromList) return;

    const user = { ...userFromList };
    const newShift = { startShift: timeStart, endShift: timeEnd };

    if (doShiftsOverlap(user, newShift)) return;

    user.shifts = [...(user.shifts ?? []), newShift];

    const globalIndex = users.findIndex((u) => u.userID === user.userID);
    if (globalIndex !== -1) updateUser(globalIndex, user);

    setTimeStart("");
    setTimeEnd("");
  };

  // ------------------------------
  // Drag & Drop Handlers
  // ------------------------------
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination || !selectedDate) return;
    const { source, destination, type } = result;

    if (type === "employee") {
      const filtered = users.filter((u) => u.date === selectedDate);
      const [moved] = filtered.splice(source.index, 1);
      filtered.splice(destination.index, 0, moved);
      setUsers((prev) => {
        const remaining = prev.filter((u) => u.date !== selectedDate);
        const newUsers = [...remaining, ...filtered];
        
        return newUsers;
      });
    } else if (type === "shift") {
      const userId = source.droppableId.replace("shifts-", "");
      reorderShifts(userId, source.index, destination.index);
    }
  };

  const reorderShifts = (userId: string, fromIndex: number, toIndex: number) => {
    setUsers((prev) => {
      const newUsers = prev.map((u) => {
        if (u.userID !== userId) return u;
        const newShifts = [...(u.shifts ?? [])];
        const [moved] = newShifts.splice(fromIndex, 1);
        newShifts.splice(toIndex, 0, moved);
        return { ...u, shifts: newShifts };
      });
      
      return newUsers;
    });
  };

  const handleAlphabetize = () => {
    if (!selectedDate) return;
    const usersForDate = users.filter((u) => u.date === selectedDate);
    const otherUsers = users.filter((u) => u.date !== selectedDate);
    usersForDate.sort((a, b) => {
      const lastCompare = a.fullName.localeCompare(b.fullName);
      return lastCompare !== 0 ? lastCompare : a.fullName.localeCompare(b.fullName);
    });
    const newUsers = [...otherUsers, ...usersForDate];
    setUsers(newUsers);
    
  };



    const copySelectedUsers = (includeShifts: boolean) => {
  if (!selectedDate) return;
  if (selectedEmployeeIDs.size === 0) return;

  const copied: ClipboardUser[] = users
    .filter(
      u =>
        u.date === selectedDate &&
        selectedEmployeeIDs.has(u.userID)
    )
    .map(u => {
      const { shifts, date: _date, ...rest } = u;

      return {
        ...rest,
        ...(includeShifts && shifts ? { shifts: [...shifts] } : {})
      };
    });

  setClipboardUsers(copied);
};



    const handleCopy = () => {
      copySelectedUsers(false);
    };

    const handleCopyWithShifts = () => {
      copySelectedUsers(true);
    };
        


//Check on Paste - pasted users against users for that date
function findRuleConflictsAndSelect(
  usersToInsert: User[],
  usersForDate: User[],
  rules: RulesUser[]
): Set<string> {
  const conflictedIDs = new Set<string>();

  for (const insertUser of usersToInsert) {
    for (const existingUser of usersForDate) {
      if (insertUser.userID === existingUser.userID) continue;

      const conflict = hasRuleConflict(
        insertUser,
        existingUser,
        rules
      );

      if (conflict) {
        conflictedIDs.add(insertUser.userID);
        break;
      }
    }
  }

  return conflictedIDs;
}



function hasRuleConflict(
  userToInsert: User,
  existingUser: User,
  rules: RulesUser[]
  ): boolean {
    return rules.some(({ userID1, userID2 }) =>
      [userID1, userID2].includes(userToInsert.userID) &&
      [userID1, userID2].includes(existingUser.userID)
    );

    
  }


const handlePaste = () => {
  if (!selectedDate) return;
  if (!clipboardUsers || clipboardUsers.length === 0) return;

  // ❌ do not paste if multiple selections
  if (selectedEmployeeIDs.size > 1) return;

  const usersForDate = users.filter(u => u.date === selectedDate);
  const otherUsers = users.filter(u => u.date !== selectedDate);

  let insertIndex = 0;

  if (selectedEmployeeIDs.size === 1) {
    const [selectedID] = Array.from(selectedEmployeeIDs);
    const foundIndex = usersForDate.findIndex(u => u.userID === selectedID);
    if (foundIndex !== -1) insertIndex = foundIndex;
  }

  const existingIDs = new Set(usersForDate.map(u => u.userID));

  const usersToInsert = clipboardUsers
    .filter(u => !existingIDs.has(u.userID))
    .map(u => ({
      ...u,
      date: selectedDate,
      shifts: [...(u.shifts ?? [])],
    }));

  if (usersToInsert.length === 0) return;

  // ✅ FIND RULE CONFLICTS
  const conflictedIDs = findRuleConflictsAndSelect(
    usersToInsert,
    usersForDate,
    rules
  );

  // ✅ SELECT CONFLICTED USERS
  if (conflictedIDs.size > 0) {
    setSelectedEmployeeIDs(conflictedIDs);
  }

  const newUsersForDate = [
    ...usersForDate.slice(0, insertIndex),
    ...usersToInsert,
    ...usersForDate.slice(insertIndex),
  ];

  const newUsers = [...otherUsers, ...newUsersForDate];

  setUsers(newUsers);
  setClipboardUsers([]);

  
};



const handleSave = async () => {
  if (!scheduleName) {
    showToast("❌ No active schedule selected");
    return;
  }

  try {
    await saveScheduleToDB({
      scheduleName,
      users,
      rules,
      firstDayOfYear,
      lastDayOfYear,
    });

    showToast(`✅ Schedule "${scheduleName}" saved`);
  } catch (err) {
    showToast(
      err instanceof Error
        ? `❌ Save failed: ${err.message}`
        : "❌ Save failed"
    );
  }
};



  return (
    <div className={styles.pageWrapper}>
      <div className={styles.container} ref={containerRef}>
        <span ref={measureRef} className={styles.measure} />

        <div className={styles.insertedWarning} style={{ visibility: areRestrictedUsersInContainer() ? "visible" : "hidden" }}>
          ⚠ Restricted Users!
        </div>

        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="employeeList" type="employee" direction="vertical">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className={styles.list}>
                {employeeList.length === 0 ? (
                  <div className={styles.itemEmpty}>No employees</div>
                ) : (
                  employeeList.map((u, i) => {
                    const id = u.userID ?? i.toString();
                    const isSelected = selectedEmployeeIDs.has(id);
                    const isRestricted = isEmployeeFullyRestricted(u);

                    return (
                      <Draggable key={id} draggableId={id} index={i}>
                        {(prov) => (
                          <div
                            ref={prov.innerRef}
                            {...prov.draggableProps}
                            {...prov.dragHandleProps}
                            className={classNames(styles.item, { [styles.selected]: isSelected })}
                            onClick={() => {
                              setSelectedEmployeeIDs((prev) => {
                                const next = new Set(prev);
                                if (next.has(id)) next.delete(id);
                                else next.add(id);
                                return next;
                              });
                            }}
                          >
                            <div className={styles.entry}>
                              <button
                                className={styles.deleteTop}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteUser(u.userID);
                                }}
                              >
                                ×
                              </button>
                              <div className={styles.names}>
                                <div
                                  className={styles.fullName}
                                  style={{ color: isRestricted ? "red" : "inherit", fontWeight: isRestricted ? "bold" : "normal" }}
                                >
                                  {u.fullName}
                                </div>

                                <Droppable droppableId={`shifts-${id}`} type="shift" direction="vertical">
                                  {(dropProv) => (
                                    <div ref={dropProv.innerRef} {...dropProv.droppableProps} className={styles.shiftsList}>
                                      {(u.shifts ?? []).map((s, si) => (
                                        <Draggable key={`shift-${id}-${si}`} draggableId={`shift-${id}-${si}`} index={si}>
                                          {(shiftProv) => (
                                            <div
                                              ref={shiftProv.innerRef}
                                              {...shiftProv.draggableProps}
                                              {...shiftProv.dragHandleProps}
                                              className={styles.shiftItem}
                                            >
                                              <span className={styles.shiftText}>
                                                {s.startShift} - {s.endShift}
                                              </span>
                                              <button
                                                className={styles.deleteShift}
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  if (!selectedDate) return;
                                                  const currentUser = employeeList[i];
                                                  const newShifts = [...(currentUser.shifts ?? [])];
                                                  newShifts.splice(si, 1);
                                                  const globalIndex = users.findIndex((uu) => uu.userID === currentUser.userID);
                                                  if (globalIndex !== -1) updateUser(globalIndex, { ...currentUser, shifts: newShifts });
                                                }}
                                              >
                                                ×
                                              </button>
                                            </div>
                                          )}
                                        </Draggable>
                                      ))}
                                      {dropProv.placeholder}
                                    </div>
                                  )}
                                </Droppable>
                              </div>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    );
                  })
                )}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        <div className={styles.form}>
          <div className={styles.nameRow}>
            

           
            {/*!!!!*/}
          <input
            type="text"
            placeholder="Full Name"
            value={fullName}
            ref={nameInputRef}
            onChange={(e) => {
              const span = measureRef.current;
              const input = nameInputRef.current;
              if (!span || !input) return;

              const computedStyle = getComputedStyle(input);
              span.style.fontSize = computedStyle.fontSize;  // ← UNCOMMENT THIS
              span.style.fontFamily = computedStyle.fontFamily;
              span.style.fontWeight = computedStyle.fontWeight;
              span.style.letterSpacing = computedStyle.letterSpacing;  // ← USE ACTUAL SPACING

              span.textContent = e.target.value;
              const rootFontSize = parseFloat(getComputedStyle(document.documentElement).fontSize);
              console.log("text width rem:", span.offsetWidth / rootFontSize);

              const maxWidthPx = (NAME_MAX_WIDTH_REM - 1) * rootFontSize;
              if (span.offsetWidth > maxWidthPx) return;

              setFullName(e.target.value);
            }}
            style={{
              width: "100%",
              maxWidth: "100%",
            }}
          />

        
                      
          </div>
          <div className={styles.row}>
            <TimeInput label="Start" value={timeStart} onChange={setTimeStart} />
            <TimeInput label="End" value={timeEnd} onChange={setTimeEnd} />
          </div>
          
          <div className={styles.buttonsRow}>
            <button
              className={classNames(styles.button, styles.SetShiftButton)}
              onClick={handleSetShift}
              disabled={selectedEmployeeIDs.size !== 1}
              title={selectedEmployeeIDs.size !== 1 ? "Select exactly one employee to set a shift" : ""}
            >
              Set Shift
            </button>
            <button className={styles.button} onClick={handleAddEmployee}>Add Employee</button>
            <button className={styles.button} onClick={handleAlphabetize}>Alphabetize</button>
            </div>
            <div className={styles.buttonsRow2}>
              <button className={styles.button} onClick={handleCopy}>Copy</button>
              <button className={styles.button} onClick={handleCopyWithShifts}>Copy w/ Date</button>
              <button className={styles.button} onClick={handlePaste}>Paste</button>
              <button className={styles.button} onClick={handleSave}>Save</button>
            </div>



          
        </div>
      </div>

      <ToastContainer toasts={toasts} />

    </div>
  );
}
