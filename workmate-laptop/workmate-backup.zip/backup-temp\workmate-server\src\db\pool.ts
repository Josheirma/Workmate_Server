import { Pool } from "pg"
import dotenv from "dotenv"

dotenv.config()

console.log("POOL CONNECTING WITH:", process.env.DATABASE_URL)

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000
})

export default pool