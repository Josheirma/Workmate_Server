import { contextBridge, ipcRenderer } from "electron";
import console from "console";

console.log("=== PRELOAD SCRIPT STARTING ===");

console.log("contextBridge available:", !!contextBridge);
console.log("ipcRenderer available:", !!ipcRenderer);

interface Api {
  schedules: {
    listSchedules: () => Promise<any>;
    getSchedule: (name: string) => Promise<any>;
    saveSchedule: (name: string, schedule: any) => Promise<void>;
    deleteSchedule: (name: string) => Promise<void>;
  };
  //postgresql added
  license: {
    verify:   () => Promise<boolean>;
    activate: (serial: string) => Promise<{ success: boolean; error?: string }>;
  };
}

const api: Api = {
  schedules: {
    listSchedules() {
      console.log("schedules.listSchedules called");
      return ipcRenderer.invoke("schedules:list");
    },

    getSchedule(name: string) {
      console.log("schedules.getSchedule called with:", name);
      return ipcRenderer.invoke("schedules:get", name);
    },

    saveSchedule(name: string, schedule: any) {
      console.log("schedules.saveSchedule called");
      return ipcRenderer.invoke("schedules:save", name, {
        users: schedule.users ?? [],
        rules: schedule.rules ?? [],
        firstDayOfYear: schedule.firstDayOfYear ?? "",
        lastDayOfYear: schedule.lastDayOfYear ?? "",
      });
    },

    deleteSchedule(name: string) {
      console.log("schedules.deleteSchedule called with:", name);
      return ipcRenderer.invoke("schedules:delete", name);
    },
  },

  //both added for postgresql
  license: {
    verify() {
      console.log("license.verify called");
      return ipcRenderer.invoke("license:verify");
    },

    activate(serial: string) {
      console.log("license.activate called with:", serial);
      return ipcRenderer.invoke("license:activate", serial);
    },
  },
};

console.log("API object created:", api);

try {
  console.log("About to expose API to main world...");
  contextBridge.exposeInMainWorld("api", api);
  console.log("✅ API successfully exposed to main world");
} catch (error) {
  console.error("❌ Failed to expose API:", error);
}

declare global {
  interface Window {
    api: Api;
  }
}