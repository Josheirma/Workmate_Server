import { createContext } from "react";
import type { RulesUser, RulesContextType } from "./types/rulesInterface";

export type { RulesUser, RulesContextType };

export const RulesContext = createContext<RulesContextType | null>(null);