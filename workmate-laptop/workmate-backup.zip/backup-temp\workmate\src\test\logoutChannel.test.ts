//unit test - npx vitest run src/test/logoutChannel.test.ts
import { describe, it, expect, beforeAll, afterAll } from "vitest";

/**
 * BroadcastChannel inherits from EventTarget in browsers.
 * Because TypeScript requires full interface compatibility,
 * our mock must:
 *   • extend EventTarget
 *   • implement all BroadcastChannel fields/methods
 * This mock is fully typed, safe, and has zero side effects.
 */
class FakeBC extends EventTarget implements BroadcastChannel {
  name: string;
  onmessage: ((this: BroadcastChannel, ev: MessageEvent) => unknown) | null =
    null;
  onmessageerror:
    | ((this: BroadcastChannel, ev: MessageEvent) => unknown)
    | null = null;

  constructor(name: string) {
    super();
    this.name = name;
  }

  postMessage(_message: unknown): void {
    // No-op mock
  }

  close(): void {
    // No-op mock
  }
}

describe("logoutChannel", () => {
  const OriginalBC = global.BroadcastChannel;

  beforeAll(() => {
    // Use fully typed BroadcastChannel mock (no any)
    global.BroadcastChannel = FakeBC;
  });

  afterAll(() => {
    global.BroadcastChannel = OriginalBC;
  });

  it("creates a valid broadcast channel", async () => {
    // Import AFTER mocking so the module uses FakeBC
    // logoutChannel is the shared communication channel used to send logout messages between all tabs of your app.
    const { logoutChannel } = await import(
      "../Scheduling/Header/logout/logoutChannel"
    );

    expect(logoutChannel).not.toBeNull();
    expect(logoutChannel?.name).toBe("app-calendar");
  });
});
