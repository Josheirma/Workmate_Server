import React, { useContext, useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { CalendarContext } from "../CalendarContext";
import styles from "./HeaderComponent.module.css";
import { RulesContext } from "../../Scheduling/MakeRulesContext";
import { NAV_LINKS} from "./constants";
//import { useMobileBreakpoint } from "./hooks/useMobileBreakpoint";

interface HeaderProps {
  header_fontsize?: number;
  header_toppadding?: number;
  header_bottompadding?: number;
  onSaveDatabase?: () => void;
}

export default function Header({ onSaveDatabase }: HeaderProps) {
  console.log("HeaderComponent loaded");
  console.log("onSaveDatabase:", onSaveDatabase);

  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);

  if (!ctx) throw new Error("HeaderComponent must be used within provider");
  if (!rulesCtx) throw new Error("HeaderComponent must be used within RulesContext.Provider");

  const {
    selectedDate,
    setSelectedDate,
    lastDayOfYear,
    firstDayOfYear,
    scheduleName,
  } = ctx;

  const location = useLocation();
  //const isMobile = useMobileBreakpoint(BREAKPOINT);
  //const [open, setOpen] = useState(false);

  const showDate = useMemo(
    () => location.pathname.startsWith("/schedules"),
    [location.pathname]
  );

  const showHrs = useMemo(
    () => location.pathname.startsWith("/hrs"),
    [location.pathname]
  );

  const isDateValid =
    selectedDate !== undefined &&
    selectedDate !== null &&
    selectedDate !== "";

  /* --------------------------------
     DATE DISPLAY FORMATTER
  ---------------------------------*/
  const formatDateMMDDYYYY = (isoDate: string) => {
    if (!isoDate) return "";
    const d = new Date(isoDate);
    if (isNaN(d.getTime())) return isoDate; // fallback
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const yyyy = d.getFullYear();
    return `${mm}/${dd}/${yyyy}`;
  };

  function handlePrevDate() {
    if (!selectedDate || !isDateValid) return;

    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);

    const firstDayDate = new Date(firstDayOfYear);
    if (d < firstDayDate) return;

    const newDate = d.toISOString().slice(0, 10);
    setSelectedDate(newDate);
  }

  function handleNextDate() {
    if (!selectedDate || !isDateValid) return;

    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);

    const lastDayDate = new Date(lastDayOfYear);
    if (d > lastDayDate) return;

    const newDate = d.toISOString().slice(0, 10);
    setSelectedDate(newDate);
  }

  return (
    <header
      className={styles.header}
      style={{
        // fontSize: `${header_fontsize}rem`, // scales font
        // paddingTop: `${header_toppadding}em`,
        // paddingBottom: `${header_bottompadding}em`,
      }}
    >
      <div className={styles.left}>Workmate</div>

      {(showDate || showHrs) && (
        <div className={styles.center} data-testid="header-date">
          <>
            {isDateValid && (
              <button
                type="button"
                className={styles.arrow}
                onClick={handlePrevDate}
                aria-label="Previous day"
              >
                ◁
              </button>
            )}

            <span className={styles.dateText}>
              {formatDateMMDDYYYY(selectedDate)}
            </span>

            {isDateValid && (
              <button
                type="button"
                className={styles.arrow}
                onClick={handleNextDate}
                aria-label="Next day"
              >
                ▷
              </button>
            )}
          </>
        </div>
      )}

      <div className={styles.right}>
        <nav className={styles.nav}>
          {/* Save Database Button - Red and Bold - FIRST */}
          <button
            onClick={onSaveDatabase}
            style={{ 
              
              cursor: 'pointer',
             
              background: 'none',
              border: 'none',
              fontSize: 'inherit',
              fontFamily: 'inherit',
              padding: 0,
              marginRight: '1.5rem',
              
            }}
          >
            Save Database
          </button>

          {/* Existing navigation links */}
          {NAV_LINKS.map((l) => (
            <Link key={l.path} to={l.path}>
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}