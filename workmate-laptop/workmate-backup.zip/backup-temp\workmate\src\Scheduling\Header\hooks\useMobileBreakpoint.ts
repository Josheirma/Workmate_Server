import { useEffect, useState } from "react";

export function useMobileBreakpoint(bp: number) {
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia(`(max-width: ${bp}px)`).matches;
  });

  useEffect(() => {
    if (typeof window === "undefined") return;

    const mq = window.matchMedia(`(max-width: ${bp}px)`);

    const handler = (ev: MediaQueryListEvent | MediaQueryList) =>
      setIsMobile("matches" in ev ? ev.matches : mq.matches);

    if (mq.addEventListener)
      mq.addEventListener("change", handler);
    else mq.addListener?.(handler);

    handler(mq);

    return () => {
      if (mq.removeEventListener)
        mq.removeEventListener("change", handler);
      else mq.removeListener?.(handler);
    };
  }, [bp]);

  return isMobile;
}
