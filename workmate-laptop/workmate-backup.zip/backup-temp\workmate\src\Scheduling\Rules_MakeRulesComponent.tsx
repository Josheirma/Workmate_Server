import  RulesProvider  from "./MakeRulesProvider";
import Rules_RulesComponent from "./Rules_RulesComponent";
import Rules_EmployeeComponent from "./Rules_EmployeeComponent";
import styles from "./Rules_MakeRulesComponent.module.css";


export default function Rules_MakeRulesComponent() {
  return (
    <RulesProvider>
      
      <div className={styles.rulesContainer}>
        <div className={styles.rulesEmployeeWrapper}>
        <Rules_EmployeeComponent />
        </div>
        
        <div className={styles.rulesRulesWrapper}>
        <Rules_RulesComponent />
        </div>
        
        </div>
      
      
      
      
    </RulesProvider>
  );
}