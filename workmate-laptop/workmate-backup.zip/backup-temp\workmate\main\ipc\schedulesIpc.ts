// IPC = Inter-Process Communication
// IPC is a way for two separate processes to talk to each other.
// In Electron, there are two main processes:
// Main process — has full access to Node, Electron APIs, can manage windows, system resources, etc.
// Renderer process — basically a web page (HTML/CSS/JS), runs in a sandboxed browser environment, limited Node access.
// These processes are separate for security and stability. The renderer cannot directly touch privileged Electron APIs.

//Without it:
//Preload calls would silently fail
//Data would appear cached or stale
//You would think Electron is “remembering” old values

// Import Electron's IPC system so the renderer (browser) can talk to the main process
import { ipcMain, IpcMainInvokeEvent } from "electron";

// Import the SQLite database connection
// This comes from better-sqlite3 or whatever wrapper you are using
// IPC just relays the request and the response.
import db from "../db/database.js";

/* ----------------------------------------------------
 * Types (exact shape crossing IPC)
 * ---------------------------------------------------- */

// This defines the exact shape of a schedule object
// This is what gets passed across IPC between
// preload <-> main <-> database
export interface StoredSchedule {
  users: unknown[];           // Array of users for the schedule
  rules: unknown[];           // Array of scheduling rules
  firstDayOfYear?: string | null;  // Optional first day
  lastDayOfYear?: string | null;   // Optional last day
}

/* ----------------------------------------------------
 * Prepared statements (MATCH TABLE EXACTLY)
 * ---------------------------------------------------- */
//the ipc gets the request from renderer runs the code and returns the result

// Log when this file is loaded so we know IPC handlers were registered
console.log("schedulesIpc.ts loaded.");

// Precompile a SQL statement that lists all schedule names
// This runs fast and avoids SQL injection
const listStmt = db.prepare(`
  SELECT name
  FROM schedules
  ORDER BY name
`);

// Precompile a SQL statement to load one schedule by name
const getStmt = db.prepare(`
  SELECT
    users_json,
    rules_json,
    first_day,
    last_day
  FROM schedules
  WHERE name = ?
`);

// Precompile a SQL statement to save (insert or update) a schedule
// ON CONFLICT(name) means:
// If the name already exists, update instead of throwing an error
// the args are not required, but make it cleaner
const saveStmt = db.prepare(`
  INSERT INTO schedules (
    name,
    users_json,
    rules_json,
    first_day,
    last_day
  )
  VALUES (?, ?, ?, ?, ?)
  ON CONFLICT(name)
  DO UPDATE SET
    users_json = excluded.users_json,
    rules_json = excluded.rules_json,
    first_day  = excluded.first_day,
    last_day   = excluded.last_day
`);

// Precompile a SQL statement to delete a schedule by name
const deleteStmt = db.prepare(`
  DELETE FROM schedules
  WHERE name = ?
`);

/* ----------------------------------------------------
 * IPC: List schedules
 * ---------------------------------------------------- */

// Register an IPC handler that React can call using
// ipcRenderer.invoke("schedules:list")
ipcMain.handle(
  "schedules:list",

  // _event is the IPC event (we don't need it here)
  (_event: IpcMainInvokeEvent) => {

    // Run the prepared SQL query to get all rows
    // Each row looks like { name: "Schedule Name" }
    const rows = listStmt.all();

    // Convert the rows into an array of just names
    // ["Schedule A", "Schedule B", ...]
    return rows.map(r => r.name);
  }
);

/* ----------------------------------------------------
 * IPC: Get a schedule
 * ---------------------------------------------------- */

// Register handler for getting a full schedule by name
ipcMain.handle(
  "schedules:get",

  // Receives the event and the schedule name
  (_event: IpcMainInvokeEvent, name: string) => {

    // Run SQL query to fetch the row
    const row = getStmt.get(name);

    // If no schedule exists, return null
    if (!row) return null;

    // Convert JSON stored in the database back into JS objects
    return {
      users: row.users_json ? JSON.parse(row.users_json) : [],
      rules: row.rules_json ? JSON.parse(row.rules_json) : [],
      firstDayOfYear: row.first_day,
      lastDayOfYear: row.last_day,
    };
  }
);

/* ----------------------------------------------------
 * IPC: Save a schedule
 * ---------------------------------------------------- */

// Register handler for saving (insert or update) a schedule
ipcMain.handle(
  "schedules:save",

  // Receives:
  // - event
  // - name of the schedule
  // - schedule object sent from preload / React
  (
    _event: IpcMainInvokeEvent,
    name: string,
    schedule: StoredSchedule
  ) => {

    // Run the SQL insert/update
    // Convert JS arrays into JSON strings for storage
    saveStmt.run(
      name,
      JSON.stringify(schedule.users),
      JSON.stringify(schedule.rules),
      schedule.firstDayOfYear ?? null,
      schedule.lastDayOfYear ?? null
    );
  }
);

/* ----------------------------------------------------
 * IPC: Delete a schedule
 * ---------------------------------------------------- */

// Register handler for deleting a schedule
ipcMain.handle(
  "schedules:delete",

  // Receives the schedule name to delete
  (_event: IpcMainInvokeEvent, name: string) => {

    // Run the SQL delete
    deleteStmt.run(name);
  }
);
