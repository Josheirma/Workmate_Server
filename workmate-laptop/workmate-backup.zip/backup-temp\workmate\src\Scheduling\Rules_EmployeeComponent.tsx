import { useContext, useState, useMemo } from "react";
import {
  DragDropContext,
  Droppable,
  Draggable,
  type DropResult,
} from "@hello-pangea/dnd";
import { RulesContext, RulesUser } from "./MakeRulesContext";
import { CalendarContext } from "./CalendarContext";
import styles from "./Rules_EmployeeComponent.module.css";
import classNames from "classnames";

export default function Rules_EmployeeComponent() {
  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);

  if (!ctx) {
    throw new Error("MakeRulesPage must be used within CalendarContext");
  }
  if (!rulesCtx) {
    throw new Error("MakeRulesComponent must be used within RulesContext.Provider");
  }

  const { users, setUsers } = ctx;
  const { rules, setRules } = rulesCtx;

  const [selectedEmployeeIds, setSelectedEmployeeIds] =
    useState<Set<string>>(new Set());

  /* ---------------------------------------
     FIX: dedupe users ONCE, outside render
  ---------------------------------------- */
  const uniqueUsers = useMemo(() => {
    const seen = new Set<string>();
    return users.filter(u => {
      if (seen.has(u.userID)) return false;
      seen.add(u.userID);
      return true;
    });
  }, [users]);

  const handleSelect = (userID: string) => {
    setSelectedEmployeeIds(prev => {
      const next = new Set(prev);
      if (next.has(userID)) {
        next.delete(userID);
      } else {
        if (next.size >= 2) return prev;
        next.add(userID);
      }
      return next;
    });
  };

  const ruleExists = (id1: string, id2: string) =>
    rules.some(r =>
      (r.userID1 === id1 && r.userID2 === id2) ||
      (r.userID1 === id2 && r.userID2 === id1)
    );

  const handleAddRule = () => {
    if (selectedEmployeeIds.size !== 2) return;

    const [id1, id2] = Array.from(selectedEmployeeIds);
    if (ruleExists(id1, id2)) return;

    const user1 = users.find(u => u.userID === id1)!;
    const user2 = users.find(u => u.userID === id2)!;

    const newRule: RulesUser = {
      userID1: user1.userID,
      fullName1: user1.fullName,
      userID2: user2.userID,
      fullName2: user2.fullName,
      isRestricted: false,
    };

    setRules(prev => [...prev, newRule]);
    setSelectedEmployeeIds(new Set());
  };

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    setUsers(prev => {
      const reordered = [...prev];
      const [moved] = reordered.splice(result.source.index, 1);
      reordered.splice(result.destination.index, 0, moved);
      return reordered;
    });
  };

  const handleAlphabetize = () => {
    setUsers(prev =>
      [...prev].sort((a, b) => a.fullName.localeCompare(b.fullName))
    );
  };

  return (
    <div className={styles.pageWrapper}>
      <h1>Employees</h1>

      <div className={styles.container}>
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="employeeList" type="employee">
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={styles.list}
              >
                {uniqueUsers.map((u, index) => {
                  const isSelected = selectedEmployeeIds.has(u.userID);

                  return (
                    <Draggable
                      key={u.userID}
                      draggableId={u.userID}
                      index={index}
                    >
                      {(prov) => (
                        <div
                          ref={prov.innerRef}
                          {...prov.draggableProps}
                          {...prov.dragHandleProps}
                          className={`${styles.item} ${
                            isSelected ? styles.selected : ""
                          }`}
                          role="button"
                          tabIndex={0}
                          aria-pressed={isSelected}
                          onClick={() => handleSelect(u.userID)}
                        >
                          <div className={styles.fullName}>
                            {u.fullName}
                          </div>
                        </div>
                      )}
                    </Draggable>
                  );
                })}

                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        <div className={styles.buttonRow}>
          <button
            className={classNames(styles.button, styles.alphaButton)}
            onClick={handleAlphabetize}
          >
            Alphabetize
          </button>

          <button
            className={styles.button}
            disabled={selectedEmployeeIds.size !== 2}
            onClick={handleAddRule}
          >
            Make rules
          </button>
        </div>
      </div>
    </div>
  );
}
