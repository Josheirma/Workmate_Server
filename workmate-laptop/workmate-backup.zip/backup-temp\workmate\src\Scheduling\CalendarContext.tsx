import { createContext } from "react";


export interface Shift {
  startShift: string;
  endShift: string;
}

export interface User {
  userID: string;
  fullName: string;
  
  shifts: Shift[];
  date: string; 
  
  
}

type ToastState = {
  message: string;
  type: "error" | "info";
} | null;


export interface CalendarContextType {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  selectedDate: string | null;
  setSelectedDate: React.Dispatch<React.SetStateAction<string | null>>;
  startDate: string | null;
  setStartDate: React.Dispatch<React.SetStateAction<string | null>>;
  endDate: string | null;
  setEndDate: React.Dispatch<React.SetStateAction<string | null>>;
  firstDayOfYear: string | null;
  setFirstDayOfYear: React.Dispatch<React.SetStateAction<string | null>>;
  lastDayOfYear: string | null;
  setLastDayOfYear: React.Dispatch<React.SetStateAction<string | null>>; 
  toast: ToastState;
  setToast: (t: ToastState) => void;   
  scheduleName: string | null;
  setScheduleName: React.Dispatch<React.SetStateAction<string | null>>;
}



export const CalendarContext = createContext<CalendarContextType | null>(null);