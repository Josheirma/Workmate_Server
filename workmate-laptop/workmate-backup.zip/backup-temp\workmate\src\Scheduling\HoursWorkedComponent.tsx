import React, { useContext, useState, useEffect } from "react";
import styles from "./HoursWorkedComponent.module.css";
import { CalendarContext, User } from "../Scheduling/CalendarContext";

export default function HoursWorkedComponent() {
  const ctx = useContext(CalendarContext);

  if (!ctx) {
    throw new Error(
      "HoursWorkedComponent must be used within CalendarContext.Provider"
    );
  }

  const { users, selectedDate } = ctx;

  const [userDates, setUserDates] = useState<Record<string, { start: string; end: string }>>({});
  const [globalStart, setGlobalStart] = useState("");
  const [globalEnd, setGlobalEnd] = useState("");
  const [hoursPerUser, setHoursPerUser] = useState<Record<string, number>>({});
  const [invalidDates, setInvalidDates] = useState<Record<string, boolean>>({});
  const [globalInvalidMessage, setGlobalInvalidMessage] = useState("");

  // Initialize defaults on mount
  useEffect(() => {
    const defaults: Record<string, { start: string; end: string }> = {};
    const startD = selectedDate ? new Date(selectedDate) : new Date();
    const endD = new Date(startD);
    endD.setDate(endD.getDate() + 7);
    const format = (d: Date) => d.toISOString().split("T")[0];

    users.forEach((u) => {
      defaults[u.userID] = { start: format(startD), end: format(endD) };
    });

    setUserDates(defaults);
    setGlobalStart(format(startD));
    setGlobalEnd(format(endD));
    setHoursPerUser({});
    setInvalidDates({});
    setGlobalInvalidMessage("");
  }, [users, selectedDate]);


  // Add these useEffect hooks after your existing useEffect



  
// Clear global error message when global dates become valid
useEffect(() => {
  if (globalStart && globalEnd) {
    const startD = new Date(globalStart + "T00:00:00");
    const endD = new Date(globalEnd + "T23:59:59");
    
    if (!isNaN(startD.getTime()) && !isNaN(endD.getTime()) && endD >= startD) {
      setGlobalInvalidMessage("");
    }
  }
}, [globalStart, globalEnd]);

// Clear individual user error messages when their dates become valid
useEffect(() => {
  const newInvalid: Record<string, boolean> = { ...invalidDates };
  let hasChanges = false;

  users.forEach((user) => {
    const dates = userDates[user.userID];
    if (dates && dates.start && dates.end) {
      const startD = new Date(dates.start + "T00:00:00");
      const endD = new Date(dates.end + "T23:59:59");
      
      if (!isNaN(startD.getTime()) && !isNaN(endD.getTime()) && endD >= startD) {
        if (newInvalid[user.userID]) {
          newInvalid[user.userID] = false;
          hasChanges = true;
        }
      }
    }
  });

  if (hasChanges) {
    setInvalidDates(newInvalid);
  }
}, [userDates, users, invalidDates]);





  // ----------------------------
  const handleChangeUser = (userID: string, type: "start" | "end", value: string) => {
    setUserDates((prev) => ({
      ...prev,
      [userID]: { ...prev[userID], [type]: value },
    }));
  };

  const getWeekday = (dateStr: string) => {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    return d.toLocaleDateString(undefined, { weekday: "short" });
  };

  function toMinutes(time: string, isEndTime = false): number {
    const match = time.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (!match) return NaN;
    let hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    const period = match[3].toUpperCase();
    if (period === "AM") {
      if (hours === 12) hours = 0;
    } else {
      if (hours !== 12) hours += 12;
    }
    let totalMinutes = hours * 60 + minutes;
    if (isEndTime && totalMinutes === 0) totalMinutes = 24 * 60;
    return totalMinutes;
  }

  // ----------------------------
  const calculateHours = () => {
    const newHours: Record<string, number> = {};
    const newInvalid: Record<string, boolean> = {};

    users.forEach((user) => {
      const dates = userDates[user.userID];
      if (!dates || !dates.start || !dates.end) {
        newHours[user.userID] = 0;
        newInvalid[user.userID] = false;
        return;
      }

      const startD = new Date(dates.start + "T00:00:00");
      const endD = new Date(dates.end + "T23:59:59");

      if (isNaN(startD.getTime()) || isNaN(endD.getTime()) || endD < startD) {
        newHours[user.userID] = 0;
        newInvalid[user.userID] = true;
        return;
      }

      let totalMinutes = 0;
      user.shifts.forEach((s) => {
        const shiftStart = toMinutes(s.startShift, false);
        const shiftEnd = toMinutes(s.endShift, true);
        if (!isNaN(shiftStart) && !isNaN(shiftEnd)) totalMinutes += shiftEnd - shiftStart;
      });

      newHours[user.userID] = totalMinutes / 60;
      newInvalid[user.userID] = false;
    });

    setHoursPerUser(newHours);
    setInvalidDates(newInvalid);
  };

  // ----------------------------
  const applyGlobalDates = () => {
    const updated: Record<string, { start: string; end: string }> = {};
    let anyInvalid = false;

    users.forEach((user) => {
      const start = globalStart;
      const end = globalEnd;

      const startD = new Date(start + "T00:00:00");
      const endD = new Date(end + "T23:59:59");

      if (isNaN(startD.getTime()) || isNaN(endD.getTime()) || endD < startD) {
        updated[user.userID] = userDates[user.userID]; // keep old
        anyInvalid = true;
      } else {
        updated[user.userID] = { start, end };
      }
    });

    setUserDates(updated);
    setGlobalInvalidMessage(anyInvalid ? "❌ The dates are in the wrong order." : "");
  };

  const clearAllDates = () => {
    const newUserDates: Record<string, { start: string; end: string }> = {};
    const startD = selectedDate ? new Date(selectedDate) : new Date();
    const endD = new Date(startD);
    endD.setDate(endD.getDate() + 7);
    const format = (d: Date) => d.toISOString().split("T")[0];

    users.forEach((u) => {
      newUserDates[u.userID] = { start: format(startD), end: format(endD) };
    });

    setUserDates(newUserDates);
    setGlobalStart(format(startD));
    setGlobalEnd(format(endD));
    setHoursPerUser({});
    setInvalidDates({});
    setGlobalInvalidMessage("");
  };

  const onViewHours = () => {
    calculateHours();
  };

  // ----------------------------
  // Render
  // ----------------------------
  return (
    <div className={styles.table}>
      <h2>Hours Worked</h2>

      {/* Top View Hours button */}
      <div className={styles.viewHoursWrapper}>
        <div
          className={styles.button}
          role="button"
          tabIndex={0}
          onClick={onViewHours}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") onViewHours();
          }}
        >
          View Hours
        </div>
      </div>

      {/* Global pickers */}
      <div className={styles.headerRow}>
        <div className={styles.datePickerContainer}>Start Date</div>
        <div className={styles.datePickerContainer}>End Date</div>
      </div>

      <div className = {styles.container}>
      
      <div className = {styles.wrapper}>
      <div className={styles.globalRow}>


        <div className={styles.globalDateContainer}>
          <div>{getWeekday(globalStart)}</div>
          <input type="date" value={globalStart} onChange={(e) => setGlobalStart(e.target.value)} />
        </div>

        <div className={styles.globalDateContainer}>
          <div>{getWeekday(globalEnd)}</div>
          <input type="date" value={globalEnd} onChange={(e) => setGlobalEnd(e.target.value)} />
        </div>

        <button className={styles.button} onClick={applyGlobalDates}>
          Change All Dates
        </button>
        
        <button className={styles.button} onClick={clearAllDates}>
          Clear All Dates
        </button>

        </div>  
        </div>




      <div className = {styles.message}>
        {globalInvalidMessage && (
          <div className={styles.invalidMessage} >
            {globalInvalidMessage}
          </div>
        )}
        </div>
        </div>
        
      

      {/* User rows */}
      {users.map((user) => {
        const hours = hoursPerUser[user.userID] ?? 0;
        const formattedHours = hours.toFixed(2).padStart(7, "0");
        const invalid = invalidDates[user.userID];

        return (
          <div key={user.userID} className={styles.row}>
            <div className={styles.datePickerContainer}>
              <div>{getWeekday(userDates[user.userID]?.start || "")}</div>
              <input
                type="date"
                value={userDates[user.userID]?.start || ""}
                onChange={(e) => handleChangeUser(user.userID, "start", e.target.value)}
              />
            </div>

            <div className={styles.datePickerContainer}>
              <div>{getWeekday(userDates[user.userID]?.end || "")}</div>
              <input
                type="date"
                value={userDates[user.userID]?.end || ""}
                onChange={(e) => handleChangeUser(user.userID, "end", e.target.value)}
              />
            </div>

            <div className={styles.username}>
            {user.fullName} —{" "}
            <span
              className={styles.hoursDisplay}
              style={{
                fontFamily:
                  hours === 0
                    ? '"Segoe UI", Roboto, sans-serif'
                    : 'monospace',
              }}
            >
              {hours === 0 ? 'Press "View Hours" to view.' : `${formattedHours} Hours`}
            </span>
            {invalid && (
              <span className={styles.invalidUserMessage}>
                ❌ The dates are in the wrong order.
              </span>
            )}
          </div>
          </div>
        );
      })}

      {/* Bottom View Hours button */}
      <div className={styles.viewHoursWrapper}>
        <div
          className={styles.button}
          role="button"
          tabIndex={0}
          onClick={onViewHours}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") onViewHours();
          }}
        >
          View Hours
        </div>
      </div>
    </div>
  );
}
