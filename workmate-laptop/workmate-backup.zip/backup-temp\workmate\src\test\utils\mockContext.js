/**
 * Pure factory to create a fully-typed mock CalendarContext.
 * Immutable, override-safe, and enterprise-grade.
 */
export function createMockContext(overrides) {
    // Stable default values (one reference per field)
    const noop = () => { };
    const base = {
        users: [],
        setUsers: noop,
        user: null,
        setUser: noop,
        selectedDate: null,
        setSelectedDate: noop,
        startDate: null,
        setStartDate: noop,
        endDate: null,
        setEndDate: noop,
        authChecked: true,
        setAuthChecked: noop,
        firstDayOfYear: null,
        setFirstDayOfYear: noop,
        lastDayOfYear: null,
        setLastDayOfYear: noop,
        tempUsers: [],
        setTempUsers: noop,
        toast: { message: "", type: "info" },
        setToast: noop,
    };
    // Freeze to prevent accidental mutations (enterprise standard)
    return Object.freeze({
        ...base,
        ...overrides,
    });
}
