export declare function useMobileBreakpoint(bp: number): boolean;
