 //- npx vitest run test/.test.ts
import type { User as FirebaseUser } from "firebase/auth";

export function createMockFirebaseUser(
  overrides: Partial<FirebaseUser> = {}
): FirebaseUser {
  return {
    uid: "mock-uid",
    email: "mock@example.com",
    emailVerified: false,
    isAnonymous: false,
    providerId: "password",

    providerData: [],
    metadata: {
      creationTime: "",
      lastSignInTime: "",
    },

    refreshToken: "",
    tenantId: null,
    phoneNumber: null,
    displayName: null,
    photoURL: null,

    delete: async () => {},
    getIdToken: async () => "mock-token",
    getIdTokenResult: async () => ({ token: "mock-token" } as any),
    reload: async () => {},
    toJSON: () => ({}),

    ...overrides,
  };
}
