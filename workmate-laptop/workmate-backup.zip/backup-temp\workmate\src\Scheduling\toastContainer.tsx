import styles from "./Toast.module.css";
import { Toast } from "./useToast";

interface Props {
  toasts: Toast[];
}

export default function ToastContainer({ toasts }: Props) {
  return (
    <div className={styles.container} aria-live="polite">
      {toasts.map(t => (
        <div key={t.id} className={styles.toast}>
          {t.message}
        </div>
      ))}
    </div>
  );
}
