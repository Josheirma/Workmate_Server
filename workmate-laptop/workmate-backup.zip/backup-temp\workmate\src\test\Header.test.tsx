//integration test - npx vitest run src/test/Header.test.ts
vi.mock("firebase/app", () => ({
  initializeApp: vi.fn(() => ({})),
}));

vi.mock("firebase/auth", () => ({
  getAuth: vi.fn(() => ({ currentUser: null })),
  onAuthStateChanged: vi.fn((_auth, cb) => cb(null)),
  signOut: vi.fn(() => Promise.resolve()),
}));

vi.mock("firebase/firestore", () => ({
  getFirestore: vi.fn(() => ({})),
}));

vi.mock("./Scheduling/Header/hooks/useMobileBreakpoint", () => ({
  useMobileBreakpoint: () => false, // force desktop mode
}));

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";

import HeaderComponent from "../Scheduling/Header/HeaderComponent";
import { CalendarContext } from "../Scheduling/CalendarContext";
import { createMockContext } from "./utils/mockContext";
import { signOut } from "firebase/auth";





//console.log("matchMedia type:", typeof window.matchMedia);
//console.log("matchMedia exists?", !!window.matchMedia);
// start on month, call files and dailygraph, logs out, sets user to null.
describe("<HeaderComponent />", () => {
  let mockCtx = createMockContext();

  beforeEach(() => {
    mockCtx = createMockContext({
      user: null,
      setUser: vi.fn(),
      setUsers: vi.fn(),
      
      setSelectedDate: vi.fn(),
      users: [],
      
    });
  });

  afterEach(() => {
    window.history.pushState({}, "", "/");
    vi.clearAllMocks();
  });

  
  
  function renderHeader(path = "/month") {
    window.history.pushState({}, "", path);
    return render(
      <BrowserRouter>
        <CalendarContext.Provider value={mockCtx}>
          <HeaderComponent />signout
        </CalendarContext.Provider>
      </BrowserRouter>
    );
  }



  it("renders navigation links", () => {
    renderHeader();
    expect(screen.getByText("Files")).toBeInTheDocument();
  });

  it("shows the date container on schedules", () => {
    renderHeader("/schedules");
    expect(screen.getByTestId("header-date")).toBeInTheDocument();
  });

  it("logs out properly", async () => {
    renderHeader();

    fireEvent.click(screen.getByText("Logout"));

    await waitFor(() => {
      expect(signOut).toHaveBeenCalledTimes(1);
    });

    expect(mockCtx.setUser).toHaveBeenCalledWith(null);
  });

  
});
