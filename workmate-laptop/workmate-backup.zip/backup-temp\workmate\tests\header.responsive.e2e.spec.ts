//E2E    -   npx playwright test :  tests/header.responsive.e2e.spec.ts
import { test, expect } from "@playwright/test";


test.describe("Header Responsive Behavior", () => {

test("Desktop login → click Print link → navigate to /Print", async ({ page }) => {

  // 1️⃣ Set viewport to mobile size
  await page.setViewportSize({ width: 1000, height: 800 });

  // 2️⃣ Go to login page
  await page.goto("/");

  // 3️⃣ Fill in email field
  await page.getByText(/email/i).locator("..").locator("input").fill("joshuaeirm@gmail.com");

  // 4️⃣ Fill in password field
  await page.getByText(/password/i).locator("..").locator("input").fill("password");

  // 5️⃣ Submit login form
  await page.getByRole("button", { name: /login/i }).click();

  // 6️⃣ Ensure we are redirected to schedules page
  await expect(page).toHaveURL(/schedules/);


  // 7️⃣ Confirm mobile nav toggle button is visible
  const printLink = page.getByRole("link", { name: /print/i });
  await expect(printLink).toBeVisible();

  await printLink.click();

   await expect(page).toHaveURL(/\/print/);

  });
 

test("Mobile login → open mobile nav → click Files → navigate to /database", async ({ page }) => {

  // 1️⃣ Set viewport to mobile size
  await page.setViewportSize({ width: 480, height: 800 });

  // 2️⃣ Go to login page
  await page.goto("/");

  // 3️⃣ Fill in email field
  await page.getByText(/email/i).locator("..").locator("input").fill("joshuaeirm@gmail.com");

  // 4️⃣ Fill in password field
  await page.getByText(/password/i).locator("..").locator("input").fill("password");

  // 5️⃣ Submit login form
  await page.getByRole("button", { name: /login/i }).click();

  // 6️⃣ Ensure we are redirected to schedules page
  await expect(page).toHaveURL(/schedules/);

  // 7️⃣ Confirm mobile nav toggle button is visible
  const toggleButton = page.getByTestId("mobile-nav-toggle");
  await expect(toggleButton).toBeVisible();

  // 8️⃣ Open mobile dropdown menu
  await toggleButton.click();

  // 9️⃣ Click "Files" in dropdown navigation
  const filesLink = page.getByRole("link", { name: /files/i });
  await filesLink.click();

  // 🔟 Verify navigation to /database page
  await expect(page).toHaveURL(/\/database/);

});
 })