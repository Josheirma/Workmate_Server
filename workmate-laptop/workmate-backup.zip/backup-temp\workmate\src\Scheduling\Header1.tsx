import React from "react";


export function Header1 (){
  return (
    <>
      
      <main style={{ padding: "0px", height: "100px", width: "100%", backgroundColor: "blue", color: "white" }}>
       TEST
      </main>
    </>
  );
}