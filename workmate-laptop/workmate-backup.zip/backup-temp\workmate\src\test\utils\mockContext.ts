import type { CalendarContextType } from "../../Scheduling/CalendarContext";

/**
 * Pure factory to create a fully-typed mock CalendarContext.
 * Immutable, override-safe, and enterprise-grade.
 */
export function createMockContext(
  overrides?: Partial<CalendarContextType>
): CalendarContextType {
  // Stable default values (one reference per field)
  const noop = () => {};

  const base: CalendarContextType = {
    users: [],
    setUsers: noop as CalendarContextType["setUsers"],

    user: null,
    setUser: noop as CalendarContextType["setUser"],

    selectedDate: null,
    setSelectedDate: noop as CalendarContextType["setSelectedDate"],

    startDate: null,
    setStartDate: noop as CalendarContextType["setStartDate"],

    endDate: null,
    setEndDate: noop as CalendarContextType["setEndDate"],

    authChecked: true,
    setAuthChecked: noop as CalendarContextType["setAuthChecked"],

    firstDayOfYear: null,
    setFirstDayOfYear: noop as CalendarContextType["setFirstDayOfYear"],

    lastDayOfYear: null,
    setLastDayOfYear: noop as CalendarContextType["setLastDayOfYear"],

    tempUsers: [],
    setTempUsers: noop as CalendarContextType["setUsers"],

    toast: { message: "", type: "info" },
    setToast: noop as CalendarContextType["setToast"],
  };

  // Freeze to prevent accidental mutations (enterprise standard)
  return Object.freeze({
    ...base,
    ...overrides,
  });
}
