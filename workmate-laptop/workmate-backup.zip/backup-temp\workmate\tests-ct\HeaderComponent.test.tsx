import { test, expect } from "@playwright/experimental-ct-react";  //// tests-ct/HeaderComponent.test.tsx
import React from "react";
import HeaderComponent from "../src/Scheduling/Header/HeaderComponent";
import { ContextWrapper } from "./helpers/ContextWrapper";
import { MemoryRouter } from "react-router-dom";
import { makeMockCalendarContext } from "./helpers/makeMockCalendarContext";

test("renders selected date", async ({ mount }) => {
  const ctx = makeMockCalendarContext({
    selectedDate: "2025-02-02",
  });

  const component = await mount(
    <MemoryRouter initialEntries={["/schedules"]}>
      <ContextWrapper ctx={ctx}>
        <HeaderComponent />
      </ContextWrapper>
    </MemoryRouter>
  );

  await expect(component.getByTestId("header-date")).toHaveText("2025-02-02");
});

test("logout is triggered with 'LOCAL'", async ({ mount }) => {
  const ctx = makeMockCalendarContext({
    selectedDate: "2025-02-02",
  });
  const component = await mount(
    <MemoryRouter initialEntries={["/schedules"]}>
      <ContextWrapper ctx={ctx}>
        <HeaderComponent />
      </ContextWrapper>
    </MemoryRouter>
  );

  await component.locator('a[href="/logout"]').click();

  // READ FROM BROWSER, NOT NODE
  const calls = await component.evaluate(() => window.__logoutCalls);

  expect(calls).toEqual(["LOCAL"]);
});
