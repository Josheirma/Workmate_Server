export {};

declare global {
  interface Window {
    __mockAuthState?: {
      uid: string | null;
      email?: string | null;
    } | null;

    __logoutCalls?: string[];
  }
}
