// playwright-ct.config.ts
import { defineConfig } from "@playwright/experimental-ct-react";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig({
  name: "ct",
  testDir: "./tests-ct",

  use: {
    ctPort: 3100,

    ctViteConfig: {
      resolve: {
        alias: {
          "../src/Scheduling/Header/hooks/useLogout":
            path.resolve(__dirname, "tests-ct/helpers/mocks.ts"),
          "../src/Scheduling/Header/hooks/useMobileBreakpoint":
            path.resolve(__dirname, "tests-ct/helpers/mocks.ts"),
          "../src/Scheduling/Header/logout/setupLogoutBroadcast":
            path.resolve(__dirname, "tests-ct/helpers/mocks.ts"),
        },
      },
      css: {
        modules: {
          localsConvention: "camelCase",
        },
      },
    },
  },
});
