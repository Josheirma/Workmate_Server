import React from "react";
import styles from "./MonthComponent.module.css";

interface DayProps {
  day: number | null;
  isToday?: boolean;
  isSelected?: boolean;
  onClick?: () => void;
  className?: string;
}

export default function DayComponent({
  day,
  isToday = false,
  isSelected = false,
  onClick,
  className = "",
}: DayProps) {
  if (!day) return <div className={`${className} ${styles.empty}`} />;

  return (
    <div
      className={`${className} ${isToday ? styles.today : ""} ${isSelected ? styles.selected : ""}`}
      onClick={onClick}
    >
      {day}
    </div>
  );
}
