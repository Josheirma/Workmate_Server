import React, { useContext, useState, useEffect } from "react";
import { CalendarContext, User } from "./CalendarContext";
import {RulesContext} from "./MakeRulesContext";
import styles from "./PrintingComponent.module.css";

import ToastContainer from "./ToastContainer";
import { useToast } from "./useToast";

export default function PrintingComponent() {
  const ctx = useContext(CalendarContext);
  const rulesCtx = useContext(RulesContext);
  const { toasts, showToast } = useToast();

  if (!ctx) {
    throw new Error(
      "PrintingComponent must be used within CalendarContext.Provider"
    );
  }
  if (!rulesCtx) {
        throw new Error(
          "DailyGraphComponent must be used within CalendarContext.Provider"
        );
  }

  const {  users } = ctx; // no optional chaining
  //const employees = Object.keys(users);

  const [startDate, setStartDate] = useState<string>(ctx.selectedDate ?? "");
  const [endDate, setEndDate] = useState<string>(ctx.selectedDate ?? "");
  const [selectedEmployee, setSelectedEmployee] = useState<string>("");
  //const foundEmployeeList: Record<string, User[]> = {};

  const [isMobile, setIsMobile] = useState<boolean>(window.innerWidth < 577);

  

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 577);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const printOneEmployeeBySelectedDates = (
  selectedEmployee: string,
  startDate: string,
  endDate: string
): void => {
  if (!selectedEmployee) {
    showToast("❌ No employee selected!");
    return;
  }

  if (!Array.isArray(users) || users.length === 0) {
    showToast("❌ No schedule data available!");
    return;
  }

  const start = new Date(startDate + " 12:00 PM");
  const end = new Date(endDate + " 12:00 PM");

  // Step 1: Group users by date, only including the selected employee within range
  const foundDates: { [date: string]: User[] } = {};

  for (const user of users) {
    const date = new Date(user.date + " 12:00 PM");
    if (date < start || date > end) continue;

    const isMatch =
      `${user.fullName}` === selectedEmployee &&
      Array.isArray(user.shifts) &&
      user.shifts.length > 0;

    if (isMatch) {
      if (!foundDates[user.date]) {
        foundDates[user.date] = [];
      }
      foundDates[user.date].push(user);
    }
  }

  if (Object.keys(foundDates).length === 0) {
    showToast(`❌ ${selectedEmployee} has no shifts in the selected date range!`);
    return;
  }

  // Step 2: Build HTML
  const html = Object.entries(foundDates)
    .map(([dateStr, userList]) => {
      const date = new Date(dateStr + " 12:00 PM");
      const displayDate = date.toLocaleDateString(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric",
        year: "numeric",
      });

      const rows = userList
        .map((u) => {
          const shifts = u.shifts
            .map((s) => `<p>${s.startShift} - ${s.endShift}</p>`)
            .join("");

          return `
          <div class="shiftRow">
            <div class="cellheader">${u.fullName}</div>
            <div class="cell">${shifts}</div>
          </div>`;
        })
        .join("");

      return `<div class="employeeSheet"><h3>${displayDate}</h3>${rows}</div>`;
    })
    .join("");

  // Step 3: Create print iframe
  const printFrame = document.createElement("iframe");
  printFrame.style.position = "fixed";
  printFrame.style.right = "0";
  printFrame.style.bottom = "0";
  printFrame.style.width = "0";
  printFrame.style.height = "0";
  printFrame.style.border = "none";

  document.body.appendChild(printFrame);
  const doc =
    printFrame.contentDocument || printFrame.contentWindow?.document;
  if (!doc) {
    showToast("❌ Unable to access print frame document!");
    return;
  }

  //body { font-family: Arial, sans-serif; margin: 20px; }
  const style = `
    
    h3 {  font-weight: bold; border-bottom: 1px solid #ccc; margin-top:20px; }
    .shiftRow { margin-left: 10px; margin-bottom: 6px; }
    .cellheader { font-weight: bold; margin-bottom: 2px; }
    .cell p { margin: 0; }
  `;

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Workmate - Employee Schedules</title>
        <style>${style}</style>
      </head>
      <body>
        <h1>${selectedEmployee}</h1>
        <p>From ${start.toDateString()} to ${end.toDateString()}</p>
        ${html}
      </body>
    </html>
  `);
  doc.close();

  // Step 4: Print and clean up
  printFrame.onload = () => {
    printFrame.contentWindow?.focus();
    printFrame.contentWindow?.print();
    setTimeout(() => {
      document.body.removeChild(printFrame);
    }, 500);
  };
};

const printAllEmployeesByDate = (
    startDate: string,
    endDate: string
  ): void => {
    if (!users || Object.keys(users).length === 0) {
      showToast("❌ No schedule data available!");
      return;
    }

    const start = new Date(startDate + " 12:00 PM");
    const end = new Date(endDate + " 12:00 PM");

    const grouped = users.reduce((acc, u) => {
  if (!u.date) return acc;
  (acc[u.date] ||= []).push(u);
  return acc;
}, {} as Record<string, User[]>);

const html = Object.entries(grouped)
  .filter(([dateStr]) => {
    const date = new Date(dateStr + " 12:00 PM");
    return date >= start && date <= end;
  })
  .map(([dateStr, userList]) => {
    const date = new Date(dateStr + " 12:00 PM");
    const displayDate = date.toLocaleDateString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });

    const rows = userList
      .map((u) => {
        const name = `${u.fullName}`;
        const shifts =
          u.shifts?.length
            ? u.shifts
                .map((s) => `<p>${s.startShift} - ${s.endShift}</p>`)
                .join("")
            : "<p>Off</p>";

        return `
        <div class="row">
          <div class="cellheader">${name}</div>
          <div class="cell">${shifts}</div>
        </div>`;
      })
      .join("");

    return `<div class="employeeSheet"><h3>${displayDate}</h3>${rows}</div>`;
  })
  .join("");


    // Step 2: Create hidden print frame
    const printFrame = document.createElement("iframe");
    printFrame.style.position = "fixed";
    printFrame.style.right = "0";
    printFrame.style.bottom = "0";
    printFrame.style.width = "0";
    printFrame.style.height = "0";
    printFrame.style.border = "none";

    document.body.appendChild(printFrame);
    const doc =
      printFrame.contentDocument || printFrame.contentWindow?.document;
    if (!doc) return showToast("❌ Unable to access print frame document!");

    //body { font-family: Arial, sans-serif; margin: 20px; }
    const style = `
    
    h3 {  font-weight: bold; margin-top: 20px;}
    .row { margin-bottom: 6px; }
    .cellheader { font-weight: bold; margin-bottom: 4px; }
    .cell p { margin: 0; }
  `;

    doc.open();
    doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Workmate - Employee Schedules</title>
        <style>${style}</style>
      </head>
      <body>
        <h1>Employee Schedules</h1>
        <p>From ${start.toDateString()} to ${end.toDateString()}</p>
        ${html}
      </body>
    </html>
  `);
    doc.close();

    // Step 3: Print
    printFrame.onload = () => {
      printFrame.contentWindow?.focus();
      printFrame.contentWindow?.print();
      setTimeout(() => {
        document.body.removeChild(printFrame);
      }, 500);
    };
  };

  const printEachEmployeeByDate = (startDate: string, endDate: string): void => {
  if (!users || Object.keys(users).length === 0) {
    showToast("❌ No schedule data available!");
    return;
  }

  const start = new Date(startDate + " 12:00 PM");
  const end = new Date(endDate + " 12:00 PM");

  // ✅ Step 1: Collect all users with dates in range
  const allEmployees: User[] = [];

  for (const emp of users) {
  if (!emp.date) continue; // skip if no date set
  const date = new Date(emp.date + " 12:00 PM");
  if (date >= start && date <= end) {
    allEmployees.push(emp);
  }
}

  if (allEmployees.length === 0) {
    showToast("❌ No employees found in selected range!");
    return;
  }

  // ✅ Step 2: Group by employee name using arrays (no Record)
  const employeeNames: string[] = [];
  const employeeGroups: { name: string; shiftsByDate: User[] }[] = [];

  for (const emp of allEmployees) {
    const fullName = `${emp.fullName}`;
    let group = employeeGroups.find((g) => g.name === fullName);

    if (!group) {
      employeeNames.push(fullName);
      group = { name: fullName, shiftsByDate: [] };
      employeeGroups.push(group);
    }

    group.shiftsByDate.push(emp);
  }

  // ✅ Step 3: Build HTML
  const html = employeeGroups
    .map(({ name, shiftsByDate }) => {
      // sort by date for cleaner layout
      const sorted = shiftsByDate.sort(
        (a, b) => new Date(a.date + " 12:00 PM").getTime() - new Date(b.date + " 12:00 PM").getTime()
      );

      const dateBlocks = sorted
        .map((u) => {
          const date = new Date(u.date + " 12:00 PM");
          const displayDate = date.toLocaleDateString(undefined, {
            weekday: "short",
            month: "short",
            day: "numeric",
            year: "numeric",
          });

          const shifts =
            u.shifts && u.shifts.length > 0
              ? u.shifts
                  .map((s) => `<p>${s.startShift} - ${s.endShift}</p>`)
                  .join("")
              : "<p>Off</p>";

          return `
          <div class="dateBlock">
            <h4>${displayDate}</h4>
            <div class="shiftRow">${shifts}</div>
          </div>`;
        })
        .join("");

      return `
      <div class="employeePage">
        <h2>${name}</h2>
        ${dateBlocks}
      </div>`;
    })
    .join("");

  // ✅ Step 4: Create hidden print frame
  const printFrame = document.createElement("iframe");
  printFrame.style.position = "fixed";
  printFrame.style.right = "0";
  printFrame.style.bottom = "0";
  printFrame.style.width = "0";
  printFrame.style.height = "0";
  printFrame.style.border = "none";
  document.body.appendChild(printFrame);

  const doc = printFrame.contentDocument || printFrame.contentWindow?.document;
  if (!doc) return showToast("❌ Unable to access print frame document!");

  // ✅ Step 5: Add styles
  //body { font-family: Arial, sans-serif; margin: 20px; }
  const style = `
  
  h1 { margin-bottom: 16px; }
  h2 { margin-bottom: 10px; border-bottom: 2px solid #ccc; padding-bottom: 4px; }
  h4 { 4px 0; font-weight: bold; margin-top: 20px; }
  .employeePage { page-break-after: always; margin-bottom: 20px; }
  .dateBlock { margin-left: 10px; margin-bottom: 10px;  }
  .shiftRow { margin-left: 20px; }
  p { margin: 0; }
`;

  // ✅ Step 6: Write printable HTML
  doc.open();
  doc.write(`
  <!DOCTYPE html>
  <html>
    <head>
      <title>Workmate - Employee Schedules</title>
      <style>${style}</style>
    </head>
    <body>
      <h1>Employee Schedules</h1>
      <p>From ${start.toDateString()} to ${end.toDateString()}</p>
      ${html}
    </body>
  </html>
`);
  doc.close();

  // ✅ Step 7: Print and clean up
  printFrame.onload = () => {
    printFrame.contentWindow?.focus();
    printFrame.contentWindow?.print();
    setTimeout(() => document.body.removeChild(printFrame), 500);
  };
};


  // Step 1: Flatten all employees across all dates
  const allEmployees = Object.values(users).flat(); // array of User[]

  // Step 2: Create a Map or Set to remove duplicates
  const uniqueEmployeesMap = new Map<string, User>();

  allEmployees.forEach((emp) => {
    const fullName = `${emp.fullName}`;
    if (!uniqueEmployeesMap.has(fullName)) {
      uniqueEmployeesMap.set(fullName, emp);
    }
  });

  // Step 3: Convert back to array for rendering
  const uniqueEmployees = Array.from(uniqueEmployeesMap.values());

  return (
    <div className={styles.pageWrapper}>
      <div className={styles.controlBox}>
        <div className={styles.datePickersRow}>
          <label className={styles.inputLabel}>Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className={styles.inputField}
          />

          <label className={styles.inputLabel}>End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className={styles.inputField}
          />
        </div>

        <div className={styles.employeeSelectRow}>
          <select
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
            className={styles.inputField}
          >
            <option value="">
              {isMobile ? "Employees" : "Select Employee"}
            </option>
            {uniqueEmployees.map((emp) => (
              <option
                key={emp.userID}
                value={`${emp.fullName}`}
              >
                {emp.fullName}
              </option>
            ))}
          </select>
          <button
            className={styles.primaryBtn}
            onClick={() =>
              printOneEmployeeBySelectedDates(
                selectedEmployee,
                startDate,
                endDate
              )
            }
          >
            Print
          </button>
        </div>

        <div className={styles.allSeparateButtonsRow}>
          <button
            className={styles.primaryBtn}
            onClick={() => printAllEmployeesByDate(startDate, endDate)}
          >
            All
          </button>
          <button
            className={styles.primaryBtn}
            onClick={() => printEachEmployeeByDate(startDate, endDate)}
          >
            Separate
          </button>
        </div>
      </div>

      <ToastContainer toasts={toasts} />
    </div>
  );
}
